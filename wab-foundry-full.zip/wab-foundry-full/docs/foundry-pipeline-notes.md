# Foundry agent pipeline: status, scope, and open points

Working notes for User Story 725441. This file is the home for everything the code deliberately does not say: who owns what, what is assumed, and what would change if an assumption turns out wrong.

**Status: provisional.** This is a first working shape built to find out what the pipeline actually needs, not a proposal that deployment is now solved. Every point marked `CONFIRM` in the pipeline is carried as a best-known value rather than a settled one.

## What this ticket covers, and what it does not

**In scope.** The pipeline: its stage shape, the build-once-promote mechanism, the gates (code quality, secret scan, tests), environment approvals, variable groups, and a deployment tool that publishes the agent idempotently and proves it answers.

**Out of scope, and owned elsewhere.** The prompt's content, the taxonomy's shape and which subjects are classifiable, the response schema's fields, how grounding is composed into instructions, and accuracy evaluation. Those are the agent, taxonomy and evaluation stories, and they are all being worked on in parallel.

That boundary is enforced in the code rather than just described here. The pipeline fingerprints the three assets as **opaque bytes**, so it detects any change to any of them without understanding a single field inside them. Where it needs the rendered instruction text to publish, it calls a seam rather than composing the text itself.

An earlier draft of this tooling did not hold that line: it inferred which subjects were parents from the taxonomy's `path` field and got 35 where the design says 8, and it filtered on an `excluded` field that does not exist yet. That is exactly the kind of quiet divergence the boundary exists to prevent.

## The dependency that decides when this can finish

The pipeline needs three things from the agent story before it can publish anything: an agent manifest, a real prompt file, and the subject reference. In the delivery repository today `foundry/agent/` holds only `__init__.py` and `classify.py`, and `foundry/prompts/` holds a placeholder.

So the sequence is:

1. **Now.** The pipeline builds, validates, fingerprints, and runs its gates. Every stage can be exercised. This is provable today.
2. **When the agent assets land.** The publish and smoke-test steps become live.
3. **When the Foundry project and its role assignment exist.** The pipeline can run against a real target.

Worth stating at standup: the Foundry pipeline is not blocked on infrastructure the way the functions and database pipelines are, but it is blocked on the agent story for its final two steps. It can be demonstrated end to end against the proven Zenon-side assets in the meantime, which is how the SDK surface gets confirmed early.

### The seam

The pipeline expects `foundry/agent/agent_definition.py` to expose `build_instructions(manifest) -> str`. That contract is a proposal, not an agreement: the proven Zenon-side module exposes `build_bundle()`, `definition_hash()` and `bundle_metadata()` instead. Whoever picks up the agent story should settle the entry point, and the pipeline will follow it. Until then, publishing fails with a message naming the missing function, and `--dry-run` still works.

## Agreed with WAB, and reflected in the pipeline

- The agent is published and versioned in Foundry as its own step, and there are separate pipelines per deployable surface. Chad Birchem, 23 July.
- Chad owns the pipelines overall; Ravi covers the Foundry part, because WAB has not built a Foundry pipeline before. Sprint planning, 20 July.
- Function apps reach Foundry through API Management, never directly. Arun Bathula, 16 June. The pipeline does not breach this: publishing a definition is a management-plane call from the build agent, not a function app calling inference. Worth saying out loud, because it looks like an exception and is not.
- Guardrails follow the Approved Foundry standard with a mandatory severity floor, and the application cannot relax them. So the pipeline never configures a content filter.
- The whole subject list goes in the prompt; no retrieval layer. Settled 22 to 23 July.
- GPT-series models are the approved standard. No specific deployment name has been pinned in any meeting; the manifest's per-environment values are placeholders.

## Assumed, not agreed

These are the ones to raise, in the order that changes the most if wrong.

1. **Code-defined agents rather than portal-authored.** No meeting settles this. Everything here assumes the agent is defined by checked-in assets and published by pipeline. If WAB prefers agents authored in the Foundry portal, most of this pipeline is redundant and the story becomes a promotion tool instead. This is the single most expensive assumption, and the cheapest to check.
2. **What promotion means.** Versioning-as-a-pipeline-step is agreed; how a version moves between environments is not. This pipeline republishes the identical definition into each environment's own project, so the same fingerprint appears in each. That is one reasonable reading.
3. **No accuracy gate on promotion.** No WAB statement chooses between Foundry Evals and a pipeline gate, so none is built. The natural insertion point is between publish and promote, once the golden set is stable.
4. **Local step templates.** This pipeline factors the deploy steps into a template so environments cannot drift. The existing pipelines in the project inline and duplicate their deploy steps per stage instead. Duplication is the house habit; the template is the better engineering. Worth a decision rather than a silent difference.

## The `CONFIRM` list

Each of these appears as a `CONFIRM` comment in the pipeline.

| Point | Carried as | Why it is uncertain |
|---|---|---|
| SonarQube task major version | `@7` | Matches the project's other pipelines; SonarSource ships `@8` and deprecates `5`. If the extension has been upgraded, these become `@8` with the same inputs. |
| SonarQube scanner mode for Python | `cli` | The standalone scanner, the counterpart of the .NET pipelines' `dotnet`. Not yet exercised on a Python project here. |
| Internal feed name | `$(artifactFeed)` | The other pipelines are .NET and show only the NuGet feed identifier. The Python feed has not been confirmed. |
| Secret scanning | provisional stand-in | No scanning task appears in either reference pipeline. Either a standard task exists, or it is a branch policy, or this sets the precedent. |
| Service connection | `$(foundryServiceConnection)` | The reference pipelines use one non-production connection across DEV, QA and UAT, and a separate one for production. |

## What only WAB can grant

| What | Who | What it blocks |
|---|---|---|
| Repository access via `APP_DEVOPS-LICENSE-BASIC` | Chandra Remella approves | Pushing a branch |
| **Foundry User** role for the pipeline identity, `53ca6127-db72-4b80-b1b0-d745d6d5456d` | Manoj Motiwala, with the access groups | Publishing; fails with 403 without it |
| **Foundry Agent Consumer** for the runtime identity, `eed3b665-ab3a-47b6-8f48-c9382fb1dad6` | same | Invocation, needed later |
| A workload-identity service connection reaching the Foundry subscription | Chad Birchem | Every deploy step |
| Azure DevOps environments `DEV` and `QA` with approvers | Chad Birchem or a project administrator | The per-stage approval requirement, which cannot be met from YAML alone |
| The internal feed name | Chad Birchem | Dependency installation |

Ask for the two roles by identifier rather than by display name: they were renamed and the older names are still in circulation.

## The deliberate divergence on secrets

The reference pipelines' variable groups hold unmasked credentials with key-vault linking off, and one of them enables verbose logging in the same group. This pipeline stores no secrets at all: it authenticates by workload identity, the runtime authenticates by managed identity, and the variable groups hold only endpoints and names.

That is a divergence a reviewer will notice, so it is better stated up front than discovered. There is nothing to store, so nothing is lost by diverging.

## Questions to take to the CI/CD conversation

1. Code-defined or portal-authored agents?
2. How does a Python project authenticate to the internal feed?
3. Is there a standard secret-scanning task or branch policy?
4. Is the SonarQube extension still on major version 7?
5. Templates or duplicated stages, given the house habit is duplication?
