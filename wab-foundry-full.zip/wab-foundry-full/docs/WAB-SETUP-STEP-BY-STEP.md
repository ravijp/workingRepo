# What to do on the WAB side, step by step

Written to be followed without needing to know how any of it works. Do the steps in order. Each one says what to do, what you should see, and what to do if it goes wrong.

The whole thing is in four parts:

- **Part 1** — get the code into the repo and prove it works on your machine. No Azure needed. About 15 minutes.
- **Part 2** — ask other people for the things only they can give you. Do this early; it is what you wait on.
- **Part 3** — set up the Azure DevOps pieces. About 30 minutes once Part 2 has landed.
- **Part 4** — run the pipeline and check it did the right thing.

---

## Part 1. Get the code in and prove it runs

### Step 1.1 — Copy the files into your branch

You are on branch `Feature/725441-ci-cd`. Copy the contents of this folder into the repository root, keeping the folder structure exactly as it is.

After copying you should have these paths in the repo:

```
foundry/agent/agent.manifest.yaml
foundry/agent/agent.manifest.json
foundry/deploy/definition.py
foundry/deploy/publish_agent.py
foundry/deploy/smoke_test.py
foundry/deploy/promote_agent.py
foundry/deploy/README.md
foundry/agent/agent_definition.py
foundry/evals/eval.py
foundry/evals/README.md
foundry/evals/data/golden.jsonl
foundry/knowledge/subject_source.tsv
foundry/knowledge/subject_reference.jsonl
foundry/knowledge/refresh_subject_reference.py
foundry/prompts/prompt_template.txt
foundry/prompts/system_v1.txt
foundry/schema/classification_output.py
foundry/schema/subject_codes.py
pipelines/deploy-foundry.yml
pipelines/templates/steps-python-setup.yml
pipelines/templates/steps-deploy-agent.yml
tests/test_agent_deploy.py
docs/foundry-pipeline-notes.md
docs/WAB-SETUP-STEP-BY-STEP.md
```

**Do not delete** the repo's existing `pipelines/ci.yml` and `pipelines/deploy.yml`. They are skeleton files from the original setup. Leave them alone; someone else may be using them.

Make sure every folder under `foundry/` has an `__init__.py` file. The repo skeleton already has them for `foundry/`, `foundry/agent/`, `foundry/schema/` and `foundry/knowledge/`. You need to add them for `foundry/deploy/` and `foundry/evals/`:

```bash
# from the repository root
type nul > foundry\deploy\__init__.py
type nul > foundry\evals\__init__.py
```

### Step 1.2 — Add the two dependencies

Open `pyproject.toml`. In the `dependencies` list, make sure these two lines are present. Add them if they are not:

```toml
    "azure-ai-projects>=2.4.0,<3.0.0",
    "azure-identity>=1.19",
```

Then update the lock file:

```bash
uv sync
```

**What you should see:** it installs packages and finishes without an error. A new or updated `uv.lock` appears in your changed files. Commit that too.

### Step 1.3 — Run the tests

```bash
uv run python -m pytest tests -q
```

**What you should see:** `33 passed`.

**If it fails:** read the first failure message. It names the file and the problem. The most likely cause is a file that did not get copied in Step 1.1.

### Step 1.4 — Run the dry run

```bash
uv run python -m foundry.deploy.publish_agent --env dev --dry-run
```

**What you should see:** a small block of JSON ending with a line like:

```
hoa-email-subject-classifier@09f1e38f0c02 [dev]: validated and fingerprinted, nothing published
```

The line above it should read `"instructions_source": "renderer"`. That means the subject list was composed into the prompt at publish time by `foundry/agent/agent_definition.py`, which is how this version works.

That twelve-character code is the **fingerprint**. It identifies this exact version of the agent. Nothing was sent anywhere; this only read your files.

### Step 1.4a — Check the prompt will survive the content filter

The prompt is sent to Foundry exactly like an email is, and it goes through the same content filter. A prompt containing something that reads as personal information gets rejected, so check it before you ever publish:

```bash
uv run python -m foundry.deploy.guardrail_check
```

**What you should see:** `instruction text is clean for publishing`.

**If it reports findings:** it names the line and the kind of pattern, without printing the value itself. Remove or replace it. Where an example value is genuinely needed in the prompt, use a bracketed label such as `[ACCOUNT]`; those are the redaction's own output and are deliberately never flagged.

This also runs in the pipeline's Build stage, so a prompt or subject description that would be rejected fails the build rather than the deployment. Worth knowing because the subject descriptions come from a business spreadsheet that nobody reviews with a content filter in mind.

### Step 1.5 — Prove the fingerprint reacts to a change

This is worth doing once so you trust it later.

1. Open `foundry/prompts/prompt_template.txt` and add a full stop somewhere.
2. Run the dry run again. No regeneration is needed in this version: the prompt template is read directly at publish time.

**What you should see:** a different fingerprint.

Now undo your edit, regenerate, and run the dry run again. The fingerprint should return to the original value. That is the whole safety mechanism: same files means same fingerprint means the pipeline will not create a duplicate agent version.

### Step 1.6 — Commit and push

```bash
git add .
git commit -m "Add Foundry agent deployment pipeline and tooling (Story 725441)"
git push origin Feature/725441-ci-cd
```

**If the push is rejected** because you cannot see the repository, that is the licensing group. Go to Step 2.1.

---

## Part 2. What to ask other people for

Raise all of these at once, on the same day. They are what you wait on, and some take days.

### Step 2.1 — Repository access, if you do not already have it

Ask for an AMS request to add you to the group **`APP_DEVOPS-LICENSE-BASIC`**. This grants access to repositories that do not need a Visual Studio Professional licence. Chandra Remella approves it.

### Step 2.2 — The two Foundry role assignments

This is the one people get wrong, so ask precisely. Ask by the identifier, not the name, because these roles were renamed and the old names are still in circulation.

> For the Case Intake Foundry project in the development environment, please grant:
>
> - the pipeline's service connection identity the role with ID `53ca6127-db72-4b80-b1b0-d745d6d5456d` (Foundry User) — it needs to create and version agents
> - the Function App's managed identity the role with ID `eed3b665-ab3a-47b6-8f48-c9382fb1dad6` (Foundry Agent Consumer) — it only needs to invoke agents
>
> Please repeat for the QA project when that exists.

Manoj Motiwala is creating the access groups, so this belongs in that conversation.

**Why it matters:** without the first one, the pipeline fails with a `403` after everything else has worked. The error message will tell you this, but it is a slow way to find out.

### Step 2.3 — The service connection

Ask Chad Birchem for a **workload identity federation** service connection that can reach the subscription holding the Foundry project, and for your pipeline to be granted permission to use it.

Write down its exact name. You need it in Step 3.2. The existing pipelines in this project use one called `WAB-Development-QASub` for dev, QA and UAT, so that may already be the right one.

### Step 2.4 — The Azure DevOps environments

Ask Chad, or a project administrator, to create two **Environments** in Azure DevOps named exactly `DEV` and `QA`, and to add an approver to each.

**Why it matters:** the acceptance criterion that each stage needs a manual approval is satisfied by these, not by anything in the YAML. If they do not exist, the pipeline runs straight through with no approval and that criterion is not met.

### Step 2.5 — The Python package feed name

Ask Chad for the name of the internal Azure Artifacts feed that Python packages come from, in the form `ProjectName/FeedName`. You need it in Step 3.1.

### Step 2.6 — The spaCy model upload

Not needed for this pipeline, but same conversation and it blocks the redaction work, so raise it now:

> The redaction module needs the spaCy English model, which is not published to any package index under a name. It is only distributed as a release wheel. Please upload `en_core_web_sm-3.7.1-py3-none-any.whl` to the internal Python feed. It is a pure-Python wheel, so nothing needs building.

### Step 2.7 — The Foundry project endpoint and model deployment

Already known from the development project, so nothing to ask for. These are the literal defaults in the manifest:

| | Value |
|---|---|
| Project | `proj-hoa-dev` |
| Project endpoint | `https://ai-eas-mfp-dev.services.ai.azure.com/api/projects/proj-hoa-dev` |
| Model deployment | `hoa-gpt-5.4-dev` |

**Confirm the endpoint by copying it from the portal** rather than trusting the value above. The portal shows it truncated on the overview page; use the copy button next to "Project endpoint". If it differs, correct it in `foundry/agent/agent.manifest.yaml` and `.json`.

**On the model choice.** The project has three deployments carrying the `hoa-` prefix: `hoa-gpt-5.4-dev`, `hoa-gpt-5.4-mini-dev` and `hoa-gpt-5-nano-dev`. The manifest uses `hoa-gpt-5.4-dev`, the most capable of the three, so the first accuracy read is not confounded by model capacity. Once accuracy is measured, comparing against `hoa-gpt-5.4-mini-dev` is a worthwhile exercise: classification over a four-thousand-token prompt is not obviously a task that needs the larger model, and the smaller one would reduce the per-email effort. Change one line in the manifest to try it, and the fingerprint stays the same because the model is deliberately not part of it.

Do **not** use the `text-embedding-3-large` deployment. That is for embeddings and cannot classify.

### Step 2.8 — The agent name

Nothing to ask for; just be aware of it. The agent publishes as:

```
hoa-email-subject-classifier
```

Deliberately **not** `case-intake-agent`, which already exists in the project for the redaction and guardrail work. Two pieces of work publishing under one agent name would overwrite each other's versions, which is a genuinely painful failure to diagnose. This name says what the agent does and follows the `hoa-` prefix the model deployments use.

---

## Part 3. Set up the Azure DevOps pieces

### Step 3.1 — Create the shared variable group

In Azure DevOps: **Pipelines → Library → + Variable group**.

Name it exactly: `AAB-HOA-CaseIntake-RELEASE`

Add these two variables:

| Name | Value |
|---|---|
| `artifactFeed` | the feed name from Step 2.5, e.g. `AAB-Epay/wab-python` |
| `variableGroupId` | leave blank for now; you fill it in Step 3.3 |

**Leave "Link secrets from an Azure key vault as variables" switched OFF.** There are no secrets here. Save.

### Step 3.2 — Create the two environment variable groups

Create a second group named exactly: `AAB-HOA-CaseIntake-DEV`

| Name | Value |
|---|---|
| `foundryServiceConnection` | the service connection name from Step 2.3 |
| `foundryProjectEndpoint` | `https://ai-eas-mfp-dev.services.ai.azure.com/api/projects/proj-hoa-dev` |

Then create a third group named exactly `AAB-HOA-CaseIntake-QA` with the same two variable names, and the QA project's values. If QA does not exist yet, put the DEV values in for now and correct them later.

### Step 3.3 — Find and record the variable group ID

Open the `AAB-HOA-CaseIntake-RELEASE` group you made in Step 3.1 and look at your browser's address bar. The URL ends with something like `...variablegroup/812`.

That number is the group's ID. Go back into the group, set `variableGroupId` to that number, and save.

**Why:** after each deployment the pipeline writes the fingerprint back into this group, so you can always see which version of the agent is live in which environment. It needs the ID to know where to write.

### Step 3.4 — Give the pipeline permission to use everything

For **each** of the three variable groups: open it, go to the **Pipeline permissions** tab, and add your pipeline (or allow all pipelines, if that is the project convention).

Then, on the `AAB-HOA-CaseIntake-RELEASE` group only, go to **Security** and give **`<ProjectName> Build Service`** the **Administrator** role.

**Why:** writing the fingerprint back needs permission to change the group. Without it the publish succeeds and then the last step fails with a `403`, which looks alarming but is only this.

### Step 3.5 — Create the pipeline

**Pipelines → New pipeline → Azure Repos Git →** pick the repository **→ Existing Azure Pipelines YAML file**.

Choose your branch `Feature/725441-ci-cd` and the path `/pipelines/deploy-foundry.yml`.

**Do not click Run yet.** Click the dropdown next to Run and choose **Save**.

Rename the pipeline to something recognisable, like `AAB-HOA-CaseIntake-Foundry`.

---

## Part 4. Run it and check it

### Step 4.1 — First run

Click **Run pipeline**. Leave the parameters at their defaults.

The Build stage should go green **without needing any Azure access at all**. If it fails, the problem is packaging or the feed, not Foundry.

### Step 4.2 — Read the results in this order

**1. Did the Build stage finish?** Look for the step "Validate assets and fingerprint the definition". It should print a fingerprint. If it did, your files are coherent.

**2. Did DEV publish?** Look at the "Publish agent to dev" step. You want to see `"action": "created"` and a version number.

**3. Did the smoke test pass?** The step after it sends one test email to the agent you just published and checks the answer has all six fields and uses a permitted subject code.

**4. Did the fingerprint get recorded?** Open the `AAB-HOA-CaseIntake-RELEASE` variable group. There should be a new variable called `CaseIntake-Foundry-DEV` holding the fingerprint, the version and the build number.

**5. Did QA wait for approval?** It should pause and ask. If it ran straight through, the Environments from Step 2.4 are not set up.

### Step 4.3 — The important test: run it a second time

Click **Run pipeline** again, changing nothing.

**What you should see:** the publish step reports `"action": "unchanged"` and does **not** create a new agent version.

This is the single most important thing to verify. It proves the pipeline is safe to re-run, which is what the "no human intervention" acceptance criterion depends on.

**If it creates a second version instead:** the idempotency check is not working. The cause is in `_list_versions` in `foundry/deploy/publish_agent.py` — the SDK call that lists existing versions is not returning them. Stop and fix that before going further, or you will accumulate a duplicate agent version on every run.

---

## When something goes wrong

| What you see | What it means | What to do |
|---|---|---|
| `403` on the publish step | The identity can sign in but is not allowed to create agents | Step 2.2, the Foundry User role |
| `401` on the publish step | Not signed in | The step must be inside an AzureCLI task on a workload identity service connection; check the service connection name in Step 3.2 |
| `403` on "Record the deployed fingerprint" | The build account cannot write to the variable group | Step 3.4, the Administrator role |
| `no project endpoint` | The endpoint variable is missing or misspelled | Step 3.2 |
| `manifest not found` | `foundry/agent/agent.manifest.json` did not get copied | Step 1.1 |
| `prompt not found` | The manifest names a prompt file that does not exist | Check `prompt_version` in the manifest matches a file in `foundry/prompts/` |
| `does not expose client.agents.list_versions` | The installed SDK version is different from expected | Fix `_list_versions` in `publish_agent.py`; it is the only place affected |
| Publish step reports guardrail risks | The prompt itself would be rejected by the content filter | Run `uv run python -m foundry.deploy.guardrail_check` locally; it names the line |
| Smoke test `400` | The content filter rejected the test email | This is a real finding, not a test fault. It means production traffic of the same shape would also be rejected. Raise it with the guardrails work. |
| Sonar step fails on an unknown input | The extension is a different major version | The pipeline uses `@7` to match the other pipelines here; if the extension is on `@8`, change the three task versions. Nothing else changes. |

---

## Where configuration lives: local runs versus pipeline runs

This is worth reading once, because it is the thing people get confused about.

There are exactly **two** values that change between environments: the **project endpoint** and the **model deployment name**. Nothing else. And neither is a secret: both are visible in the Foundry portal, and there is no key, password or connection string anywhere in this solution.

### The resolution order

Every run resolves those two values the same way, highest wins:

| | Source | Used by |
|---|---|---|
| 1 | A command line argument (`--endpoint`, `--model`) | Ad hoc runs when you want to point somewhere else once |
| 2 | An environment variable | **How the pipeline supplies them.** The variable group sets them on the build agent |
| 3 | The literal value in `foundry/agent/agent.manifest.yaml` | **How your local run works with no setup at all** |

A value written in the manifest as `${FOUNDRY_PROJECT_ENDPOINT}` means "there is no default, read it from the environment". A literal value means "this is the default".

### So, running locally

Nothing to set up. Development carries real literal values in the manifest:

```
dev:
  model_deployment: hoa-gpt-5.4-dev
  project_endpoint: https://ai-eas-mfp-dev.services.ai.azure.com/api/projects/proj-hoa-dev
```

So this just works after `az login`:

```bash
uv run python -m foundry.deploy.publish_agent --env dev
```

To point at something else for one run, pass it:

```bash
uv run python -m foundry.deploy.publish_agent --env dev --model hoa-gpt-5.4-mini-dev
```

**There is no `.env` file and there must not be one.** Nothing here needs hiding, and a `.env` is where secrets start creeping in. If you find yourself wanting one, the value you are trying to hide probably should not exist.

### And running in the pipeline

The variable group supplies the same two values as environment variables, which override the manifest defaults. That is the whole mechanism. `AAB-HOA-CaseIntake-DEV` holds `foundryProjectEndpoint` and `foundryServiceConnection`; the pipeline passes the endpoint to the command with `--endpoint "$(foundryProjectEndpoint)"`.

Why keep defaults in the manifest at all, if the pipeline overrides them? Because it means a broken pipeline variable is obvious: the run either uses the value you set or falls back to a development value you can recognise, rather than failing with an empty string.

### Why the higher environments demand their values

QA, UAT and Live are written as `${FOUNDRY_...}` on purpose. Those projects do not exist yet, so there is no honest default to write. If someone runs `--env qa` before the variable group is set up, they get a clear message naming what is missing, instead of quietly publishing into the development project.

### What is deliberately NOT in a variable group

The **agent name**, the **prompt**, the **schema** and the **subject list** are all in the repository, not in configuration. They are what the agent *is*, so they belong under version control and in the fingerprint. If they lived in a variable group, someone could change what the agent does without a commit, a review, or a new agent version.

---

## Changing the subject list later

The list of 51 subjects is generated, so never edit the generated files by hand.

1. Edit `foundry/knowledge/subject_source.tsv` — the spreadsheet columns, tab separated.
2. Run `uv run python -m foundry.knowledge.refresh_subject_reference`
3. Commit all four changed files together: the source, `subject_reference.jsonl`, `subject_codes.py`, and `system_v1.txt`.

The next pipeline run will produce a new fingerprint and publish a new agent version.

**Every subject in the source is offered to the model.** Nothing is withheld and nothing is inferred from the subject path. Where two subjects could both apply, the boundary lives in their descriptions ("Prefer ACH Fraud, Check Fraud, Fraud Alert or Other Fraud when one of them fits"), so tightening a distinction is an edit to a description rather than a code change. The generator prints the count every time it runs, so read that line and check it is what you expect.

To check nothing has drifted without regenerating:

```bash
uv run python -m foundry.knowledge.refresh_subject_reference --check
```

---

## Two extra things this version can do

### Promote a definition between environments

Once a definition is live in DEV and you want the identical one in QA:

```bash
uv run python -m foundry.deploy.promote_agent --from dev --to qa --check
```

`--check` reports what is present in both and changes nothing. Drop it to actually promote. It refuses to promote a definition that is not the one currently published in the source environment, so you cannot accidentally promote your uncommitted working copy.

### Measure accuracy

The pipeline has an accuracy gate, switched **off** by default because no accuracy threshold has been agreed. To see the numbers without gating anything:

```bash
uv run python -m foundry.evals.eval --env dev
```

It reports subject accuracy, priority accuracy, and accuracy split by confidence band. The last one matters most: the confidence threshold the decision gate uses has to come from measurement, and this is the measurement.

The sample set in `foundry/evals/data/golden.jsonl` has three illustrative rows so the harness runs. The real labelled set is another story's deliverable.
