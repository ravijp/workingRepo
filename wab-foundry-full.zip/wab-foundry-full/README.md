# Case Intake Foundry surface — the full version

This is **Version B** of two. It carries the whole Foundry surface as currently understood: the agent declared as code, the instruction composer, the response contract, the subject reference, deployment and promotion tooling, an accuracy harness, and a pipeline covering all four environments.

**Version A** (`wab-foundry-cicd`) is the alternative: the pipeline and its deployment tooling only, scoped strictly to the CI/CD story, depending on nothing another story owns.

## Choosing between them

| | Version A, minimal | Version B, full |
|---|---|---|
| Scope | The CI/CD story only | The whole Foundry surface |
| Files | 24 | 34 |
| Tests | **32** | **41** |
| Pipeline stages | Build, DEV, QA | Build, DEV, QA, UAT, PROD |
| Instruction text | Generated once, static | Composed at publish time, so exclusions take effect immediately |
| Guardrail pre-flight on the prompt | Yes | Yes |
| Promotion tool | No | Yes |
| Accuracy harness | No | Yes, off by default |
| Risk if the agent design changes | Nearly none | Composer and schema wiring may need rework |
| Risk of stepping on another ticket | Nearly none | Real: it implements taxonomy and prompt decisions |

**Take Version A** if the point is to land the CI/CD story cleanly while the taxonomy, prompt and evaluation work proceed independently. It cannot conflict with them, because it makes none of their decisions.

**Take Version B** if the point is to see the whole thing working end to end, or to have something concrete to review against. Expect to hand parts of it over as the other stories land, and expect some of those parts to be replaced rather than adopted.

A middle path worth considering: ship Version A as the ticket, and keep Version B as a working reference on a branch nobody merges.

## What is in here

```
foundry/
  agent/
    agent.manifest.yaml / .json   What the agent is built from
    agent_definition.py           Composes the prompt with the subject list
  prompts/prompt_template.txt     The instruction text, with the list composed in
  knowledge/subject_source.tsv    The 51 subjects: the one place to edit
  schema/classification_output.py The response contract, six fields
  evals/                          Accuracy harness, not agreed, off by default
  deploy/
    definition.py                 Resolve and fingerprint. No Azure dependency.
    guardrail_check.py            Check the prompt against the content filter
    publish_agent.py              Publish idempotently
    promote_agent.py              Promote a definition between environments
    smoke_test.py                 Prove the published agent answers
pipelines/
  deploy-foundry.yml              Build, then one stage per environment
  templates/                      Python setup; publish, verify, record
tests/
  test_agent_deploy.py            Deployment tooling
  test_agent_definition.py        Composition
docs/foundry-pipeline-notes.md    Status, assumptions, open points
```

## The subject list

All **51 subjects** from the agreed list are offered to the model. Nothing is withheld, and nothing is inferred from the subject path.

Where two subjects could both apply, the boundary is carried in their descriptions rather than by removing options: "Prefer ACH Fraud, Check Fraud, Fraud Alert or Other Fraud when one of them fits", "If services move to an acquiring management company, use Client Merger". That is deliberate. Tightening a distinction becomes an edit to a description, reviewable in a pull request, rather than a change to code.

The list is generated from `foundry/knowledge/subject_source.tsv` into three artefacts: the grounding reference, the schema's permitted values, and the instruction text. Never edit those three by hand. `--check` mode fails the build if a regeneration was forgotten.

`subject_id` is empty on every row. The source has no identifier column and the write-back needs one, so it is joined from the customer relationship management export before go-live rather than invented here.


## Running it

```bash
uv run python -m pytest tests -q
uv run python -m foundry.deploy.publish_agent --env dev --dry-run
```

Both work with no Azure access. For a real publish, sign in and supply an endpoint; see `foundry/deploy/README.md`.

## Status

Provisional. Notably **not** agreed with WAB: that agents are defined in code rather than authored in the Foundry portal, what promotion means between environments, and whether accuracy gates promotion. All three are recorded in `docs/foundry-pipeline-notes.md` with what would change if they go the other way.

Platform surface validated against Microsoft documentation: 2026-07-29.
