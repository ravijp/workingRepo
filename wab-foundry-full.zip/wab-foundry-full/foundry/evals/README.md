# foundry/evals

Accuracy measurement for the published agent.

**Status: not agreed.** Whether accuracy gates promotion, and whether the measurement runs as a pipeline step or as a Foundry evaluation, has not been settled. This is here so the shape is concrete and reviewable, and it is off by default in the pipeline. Its presence is not a decision.

`eval.py` invokes the published agent over a labelled sample and reports subject accuracy, priority accuracy, and accuracy by confidence band. The last of those matters most: the decision threshold has to be calibrated from measurement rather than chosen up front, and this is the measurement that would inform it.

`data/golden.jsonl` holds three illustrative rows so the harness runs. The real labelled set is the evaluation story's deliverable and is built from the customer relationship management extract; it does not live here.

Run it reporting only:

```bash
uv run python -m foundry.evals.eval --env dev
```

Run it as a gate, once a threshold exists that came from measurement:

```bash
uv run python -m foundry.evals.eval --env dev --min-subject-accuracy 0.75
```

Two failure modes are kept separate on purpose. A row that cannot be scored at all is a reliability problem and is counted against `--max-error-rate`. A row that scores wrongly is an accuracy problem and counts against the accuracy threshold. Collapsing them would let a broken deployment look like a quality regression.
