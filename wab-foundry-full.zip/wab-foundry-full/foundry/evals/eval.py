"""Measure the published agent against a labelled sample, and gate on the result.

STATUS: not agreed. Whether accuracy gates promotion, and whether the measurement
runs here or as a Foundry evaluation, has not been settled with WAB. This exists so
the shape of the gate is concrete and reviewable, and it is off by default in the
pipeline. Do not read its presence as a decision.

    python -m foundry.evals.eval --env dev --dataset foundry/evals/data/golden.jsonl
    python -m foundry.evals.eval --env dev --min-subject-accuracy 0.75

Each dataset row is one labelled email:

    {"id": "...", "email": "...", "expected_category": "...", "expected_priority": "High"}

What is measured, and what is deliberately not. Subject accuracy is the headline:
the proportion of rows where the agent returned the labelled subject. Priority
accuracy is reported beside it. Accuracy by confidence band is reported because
the decision threshold has to be calibrated from measurement rather than guessed,
and this is the measurement that informs it. Nothing here judges whether a label
is correct: the labelled set's quality is the evaluation story's concern, and
historic banker choices are known to be imperfect.
"""

from __future__ import annotations

import argparse
import json
import sys
from collections import Counter
from pathlib import Path

from foundry.deploy.definition import build, environment_binding, repo_root
from foundry.deploy.smoke_test import SmokeFailure, _invoke, validate

BANDS = ((0.9, "high (0.9+)"), (0.5, "medium (0.5-0.9)"), (0.0, "low (<0.5)"))


def _band(confidence: float) -> str:
    for floor, label in BANDS:
        if confidence >= floor:
            return label
    return "low (<0.5)"


def load_dataset(path: Path) -> list[dict]:
    if not path.is_file():
        raise SystemExit(f"dataset not found: {path}")
    rows = []
    for number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        line = line.strip()
        if not line:
            continue
        try:
            row = json.loads(line)
        except json.JSONDecodeError as exc:
            raise SystemExit(f"{path}:{number}: not valid JSON: {exc}") from exc
        for field in ("email", "expected_category"):
            if field not in row:
                raise SystemExit(f"{path}:{number}: row is missing '{field}'")
        rows.append(row)
    if not rows:
        raise SystemExit(f"dataset is empty: {path}")
    return rows


def run(endpoint: str, rows: list[dict], schema: dict, agent_name: str) -> dict:
    subject_hits = 0
    priority_hits = 0
    priority_scored = 0
    errors: list[str] = []
    by_band: dict[str, Counter] = {}

    for index, row in enumerate(rows, 1):
        identifier = row.get("id") or f"row {index}"
        try:
            answer = validate(_invoke(endpoint, agent_name, row["email"]), schema)
        except SmokeFailure as exc:
            errors.append(f"{identifier}: {exc}")
            continue
        except Exception as exc:  # noqa: BLE001 - one bad row must not end the run
            errors.append(f"{identifier}: {type(exc).__name__}: {exc}")
            continue

        correct = answer.get("category") == row["expected_category"]
        subject_hits += int(correct)

        band = _band(float(answer.get("confidence", 0)))
        counter = by_band.setdefault(band, Counter())
        counter["total"] += 1
        counter["correct"] += int(correct)

        if "expected_priority" in row:
            priority_scored += 1
            priority_hits += int(answer.get("priority") == row["expected_priority"])

    scored = len(rows) - len(errors)
    return {
        "rows": len(rows),
        "scored": scored,
        "errors": len(errors),
        "error_detail": errors[:10],
        "subject_accuracy": round(subject_hits / scored, 4) if scored else 0.0,
        "priority_accuracy": (
            round(priority_hits / priority_scored, 4) if priority_scored else None
        ),
        "by_confidence_band": {
            band: {
                "total": counts["total"],
                "correct": counts["correct"],
                "accuracy": round(counts["correct"] / counts["total"], 4),
            }
            for band, counts in sorted(by_band.items())
        },
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    parser.add_argument("--env", required=True)
    parser.add_argument("--endpoint", default=None)
    parser.add_argument("--dataset", type=Path, default=Path("foundry/evals/data/golden.jsonl"))
    parser.add_argument("--min-subject-accuracy", type=float, default=None)
    parser.add_argument("--max-error-rate", type=float, default=0.05)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)

    root = repo_root()
    definition = build(root)
    endpoint = args.endpoint
    if not endpoint:
        endpoint = environment_binding(root, args.env).get("project_endpoint", "")
    if not endpoint or endpoint.startswith("${"):
        print("##vso[task.logissue type=error]no usable project endpoint", flush=True)
        return 2

    report = run(endpoint, load_dataset(args.dataset), definition.response_schema, definition.name)
    report["environment"] = args.env
    report["definition_fingerprint"] = definition.definition_hash

    print(json.dumps(report, indent=2), flush=True)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(report, indent=2), encoding="utf-8")

    failed = False
    error_rate = report["errors"] / report["rows"] if report["rows"] else 1.0
    if error_rate > args.max_error_rate:
        print(
            f"##vso[task.logissue type=error]{report['errors']} of {report['rows']} rows "
            f"could not be scored ({error_rate:.1%}), above the {args.max_error_rate:.1%} "
            "limit. That is a reliability problem, not an accuracy one.",
            flush=True,
        )
        failed = True

    if args.min_subject_accuracy is not None:
        if report["subject_accuracy"] < args.min_subject_accuracy:
            print(
                f"##vso[task.logissue type=error]subject accuracy "
                f"{report['subject_accuracy']:.1%} is below the required "
                f"{args.min_subject_accuracy:.1%}",
                flush=True,
            )
            failed = True
    else:
        print(
            "##[warning]No accuracy threshold was supplied, so this run reports but "
            "does not gate. A threshold should come from measurement rather than "
            "being chosen up front.",
            flush=True,
        )

    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
