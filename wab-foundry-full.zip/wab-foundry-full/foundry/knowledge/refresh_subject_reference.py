"""Regenerate the subject reference and the response schema's subject list.

The subject list arrives as a spreadsheet. This turns it into the two artefacts the
agent needs, so that neither is hand-maintained and the two can never disagree:

  foundry/knowledge/subject_reference.jsonl   the grounding, one row per subject
  foundry/schema/subject_codes.py            the permitted values on the schema
  foundry/prompts/system_v1.txt              the complete instruction text

    python -m foundry.knowledge.refresh_subject_reference
    python -m foundry.knowledge.refresh_subject_reference --check

Run it after every taxonomy change, and commit both outputs with the source. The
`--check` mode regenerates in memory and fails if the committed files are stale,
which is what the pipeline runs so a forgotten refresh cannot reach Foundry.

EVERY SUBJECT IN THE SOURCE IS SELECTABLE. The source list is the set of subjects
the agent may return, in full. Nothing is withheld and nothing is inferred from the
subject path: the path is recorded because it is how the business names the subject,
not as a signal about whether it can be chosen.

Where two subjects overlap, the descriptions carry the boundary, telling the model
to prefer the more specific one. That is deliberately a matter of wording rather
than of filtering, so a change of mind is an edit to a description and not a change
to this code.
"""

from __future__ import annotations

import argparse
import csv
import json
import re
import sys
from pathlib import Path

SOURCE = "foundry/knowledge/subject_source.tsv"
REFERENCE = "foundry/knowledge/subject_reference.jsonl"
CODES_MODULE = "foundry/schema/subject_codes.py"
PROMPT_TEMPLATE = "foundry/prompts/prompt_template.txt"
PROMPT_OUTPUT = "foundry/prompts/system_v1.txt"

SUBJECT_PLACEHOLDER = "{{SUBJECT_LIST}}"

ROOT_SEGMENT = "AAB-OPS"


def repo_root() -> Path:
    return Path(__file__).resolve().parent.parent.parent


def slugify(title: str) -> str:
    """A stable machine code for a subject title.

    Lower case, punctuation dropped, spaces and separators collapsed to single
    underscores. Deterministic, because the code is what the model returns and
    what the write-back keys on, so it must not drift when a title is re-typed.
    """
    text = title.lower()
    text = text.replace("&", " and ")
    # Drop apostrophes rather than letting them become separators, so
    # "Cashier's Check" is cashiers_check and not cashier_s_check.
    text = text.replace("'", "").replace("’", "")
    text = re.sub(r"[^a-z0-9]+", "_", text)
    return text.strip("_")


def parse_source(path: Path) -> list[dict]:
    if not path.is_file():
        raise SystemExit(f"source not found: {path}")
    rows: list[dict] = []
    with path.open(encoding="utf-8", newline="") as handle:
        for line_number, raw in enumerate(csv.DictReader(handle, delimiter="\t"), 2):
            subject_path = (raw.get("subject_path") or "").strip()
            title = (raw.get("case_subject") or "").strip()
            if not subject_path and not title:
                continue
            if not subject_path or not title:
                raise SystemExit(
                    f"{path}:{line_number}: both subject_path and case_subject are required"
                )
            segments = [part.strip() for part in subject_path.split(">") if part.strip()]
            if segments and segments[0] == ROOT_SEGMENT:
                segments = segments[1:]
            if not segments:
                raise SystemExit(f"{path}:{line_number}: path has no subject after the root")
            if segments[-1] != title:
                raise SystemExit(
                    f"{path}:{line_number}: the path ends in {segments[-1]!r} but the "
                    f"case subject is {title!r}; they must agree"
                )
            rows.append(
                {
                    "code": slugify(title),
                    "title": title,
                    "path": subject_path,
                    "definition": (raw.get("description") or "").strip(),
                            "line": line_number,
                }
            )
    if not rows:
        raise SystemExit(f"no subjects found in {path}")
    return rows


def validate(rows: list[dict]) -> None:
    seen: dict[str, dict] = {}
    for row in rows:
        if row["code"] in seen:
            other = seen[row["code"]]
            raise SystemExit(
                f"two subjects produce the same code {row['code']!r}: "
                f"{other['title']!r} (line {other['line']}) and "
                f"{row['title']!r} (line {row['line']}). Codes must be unique, "
                "because the code is what the model returns."
            )
        seen[row["code"]] = row
        if not row["definition"]:
            raise SystemExit(
                f"line {row['line']}: {row['title']!r} has no description. The model "
                "distinguishes subjects by their descriptions, so an empty one makes "
                "the subject unusable."
            )

    if not rows:
        raise SystemExit("the source list is empty, so the agent would have nothing to choose")


def build_reference(rows: list[dict]) -> str:
    lines = []
    for row in rows:
        record = {
            "code": row["code"],
            "title": row["title"],
            "path": row["path"],
            "definition": row["definition"],
            # Reserved for the CRM subject identifier. The source spreadsheet does
            # not carry it, and the write-back needs it, so it is joined in from
            # the CRM export before go-live rather than invented here.
            "subject_id": None,
        }
        lines.append(json.dumps(record, ensure_ascii=False))
    return "\n".join(lines) + "\n"


def build_codes_module(rows: list[dict]) -> str:
    codes = [row["code"] for row in rows]
    body = "\n".join(f'    "{code}",' for code in codes)
    return (
        '"""The permitted subject codes. GENERATED - do not edit by hand.\n'
        "\n"
        f"Regenerate with:  python -m foundry.knowledge.refresh_subject_reference\n"
        f"Source of truth:  {SOURCE}\n"
        "\n"
        "Kept in its own module so the response schema and the grounding are\n"
        "generated from one list and cannot drift apart.\n"
        '"""\n'
        "\n"
        "from __future__ import annotations\n"
        "\n"
        "from typing import Literal\n"
        "\n"
        f"# {len(codes)} leaf subjects.\n"
        "SUBJECT_CODES: tuple[str, ...] = (\n"
        f"{body}\n"
        ")\n"
        "\n"
        "# Spelled out rather than derived from the tuple above: Literal accepts\n"
        "# literal values only, so a variable inside it is invalid typing and\n"
        "# Pydantic cannot build a validator from it.\n"
        "SubjectCode = Literal[\n"
        f"{body}\n"
        "]\n"
    )


def render_subject_block(rows: list[dict]) -> str:
    """The subject list as the model sees it.

    Each subject carries its description, because the description is the only thing
    that distinguishes one subject from a similarly named neighbour. Early accuracy
    work is expected to turn on sharpening exactly these lines.
    """
    return "\n".join(
        f"- {row['code']}: {row['title']}\n    {row['definition']}"
        for row in rows
    )


def build_prompt(root: Path, rows: list[dict]) -> str:
    """The complete instruction text: the template with the subject list in it."""
    template_path = root / PROMPT_TEMPLATE
    if not template_path.is_file():
        raise SystemExit(f"prompt template not found: {template_path}")
    template = template_path.read_text(encoding="utf-8")
    if template.count(SUBJECT_PLACEHOLDER) != 1:
        raise SystemExit(
            f"{template_path} must contain {SUBJECT_PLACEHOLDER} exactly once "
            f"(found {template.count(SUBJECT_PLACEHOLDER)})"
        )
    header = (
        "GENERATED FILE - do not edit directly.\n"
        f"Edit {PROMPT_TEMPLATE} or {SOURCE}, then run:\n"
        "  python -m foundry.knowledge.refresh_subject_reference\n"
        "\n"
    )
    return header + template.replace(SUBJECT_PLACEHOLDER, render_subject_block(rows))


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    parser.add_argument(
        "--check",
        action="store_true",
        help="Fail if the committed files differ from what the source produces.",
    )
    args = parser.parse_args(argv)

    root = repo_root()
    rows = parse_source(root / SOURCE)
    validate(rows)

    outputs = {
        root / REFERENCE: build_reference(rows),
        root / CODES_MODULE: build_codes_module(rows),
        root / PROMPT_OUTPUT: build_prompt(root, rows),
    }

    if args.check:
        stale = [
            path
            for path, content in outputs.items()
            if not path.is_file() or path.read_text(encoding="utf-8") != content
        ]
        if stale:
            for path in stale:
                print(
                    f"##vso[task.logissue type=error]{path.relative_to(root)} is out of "
                    "date. Run: python -m foundry.knowledge.refresh_subject_reference",
                    flush=True,
                )
            return 1
        print(f"subject reference is current: {len(rows)} subjects", flush=True)
        return 0

    for path, content in outputs.items():
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")
        print(f"wrote {path.relative_to(root)}")

    print(f"{len(rows)} subjects, all selectable.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
