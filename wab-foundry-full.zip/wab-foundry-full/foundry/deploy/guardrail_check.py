"""Check the instruction text before it is published, so the guardrail cannot reject it.

The prompt is sent to Foundry just like an email is, and it passes through the same
content filters. A prompt carrying something that looks like personal information
gets the publish rejected, or worse, gets the agent published and then every
invocation blocked. Either way the failure surfaces far from its cause, so it is
cheaper to catch here.

This runs on the exact text about to be published, after the subject list has been
composed in, because the subject descriptions come from a business spreadsheet and
nobody reviews them with a content filter in mind.

    python -m foundry.deploy.guardrail_check

WHAT IT LOOKS FOR. Shapes that a personal-information filter reacts to: email
addresses, telephone numbers, long digit runs that could be an account or card
number, national identifier patterns, and identifiers that look like real record
keys. It does NOT try to detect names, because any list of first names produces
constant false positives against ordinary words and would make the check useless.

WHAT IT DELIBERATELY ALLOWS. The bracketed placeholder tokens the orchestrator
substitutes, such as [NAME] and [ACCOUNT], because those are the redaction's
output and the prompt has to describe them. And the fraud vocabulary in the subject
descriptions, which is the bank's own domain language describing categories of work
rather than instructions to do anything.
"""

from __future__ import annotations

import argparse
import re
import sys
from dataclasses import dataclass


@dataclass(frozen=True)
class Finding:
    rule: str
    excerpt: str
    why: str

    def render(self) -> str:
        return f"{self.rule}: {self.excerpt} - {self.why}"


# A bracketed placeholder is the redaction's own output and must not be flagged.
PLACEHOLDER = re.compile(r"\[[A-Z_]{2,30}\]")

RULES: tuple[tuple[str, re.Pattern[str], str], ...] = (
    (
        "email address",
        re.compile(r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b"),
        "reads as a real mailbox and will be treated as personal information",
    ),
    (
        "telephone number",
        re.compile(r"(?<!\d)(?:\+?\d{1,2}[ .-]?)?\(?\d{3}\)?[ .-]\d{3}[ .-]\d{4}(?!\d)"),
        "reads as a real telephone number",
    ),
    (
        "national identifier",
        re.compile(r"(?<!\d)\d{3}-\d{2}-\d{4}(?!\d)"),
        "matches the shape of a national identifier",
    ),
    (
        "payment card number",
        re.compile(r"(?<!\d)(?:\d[ -]?){13,19}(?!\d)"),
        "matches the shape of a payment card number",
    ),
    (
        "long digit run",
        re.compile(r"(?<!\d)\d{9,}(?!\d)"),
        "a run of nine or more digits reads as an account or reference number",
    ),
    (
        "record identifier",
        re.compile(
            r"\b[0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{12}\b"
        ),
        "a globally unique identifier looks like a real record key",
    ),
)


def scan(text: str) -> list[Finding]:
    """Findings in the text, with the placeholder tokens masked out first."""
    # Blank the placeholders so they cannot themselves match, while keeping the
    # text the same length so excerpts stay meaningful.
    masked = PLACEHOLDER.sub(lambda m: " " * len(m.group(0)), text)

    findings: list[Finding] = []
    for rule, pattern, why in RULES:
        for match in pattern.finditer(masked):
            excerpt = match.group(0).strip()
            if not excerpt:
                continue
            # Never echo the matched value in full: it may be the very thing that
            # should not be reproduced. Show enough to locate it.
            shown = excerpt[:4] + "..." if len(excerpt) > 6 else "..."
            line = masked.count("\n", 0, match.start()) + 1
            findings.append(Finding(rule, f"line {line}, starts {shown!r}", why))
    return findings


def assert_clean(text: str, what: str = "the instruction text") -> None:
    """Raise if the text would risk a content-filter rejection."""
    findings = scan(text)
    if findings:
        detail = "\n".join(f"  - {finding.render()}" for finding in findings)
        raise GuardrailRisk(
            f"{what} carries {len(findings)} pattern(s) that a personal-information "
            f"filter is likely to reject:\n{detail}\n"
            "Remove or replace them. Use a bracketed placeholder such as [ACCOUNT] "
            "where an example value is genuinely needed."
        )


class GuardrailRisk(RuntimeError):
    """The text would risk being rejected by the content filter."""


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    parser.add_argument(
        "--show",
        action="store_true",
        help="Print the instruction text that would be published.",
    )
    args = parser.parse_args(argv)

    from .definition import build, repo_root

    definition = build(repo_root())
    if args.show:
        print(definition.instructions)

    findings = scan(definition.instructions)
    if findings:
        for finding in findings:
            print(f"##vso[task.logissue type=error]{finding.render()}", flush=True)
        print(
            f"##vso[task.logissue type=error]{len(findings)} guardrail risk(s) in the "
            "instruction text; see foundry/deploy/guardrail_check.py",
            flush=True,
        )
        return 1

    print(
        f"instruction text is clean for publishing "
        f"({len(definition.instructions)} characters checked against "
        f"{len(RULES)} patterns)",
        flush=True,
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
