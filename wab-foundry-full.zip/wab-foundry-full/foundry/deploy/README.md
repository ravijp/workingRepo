# foundry/deploy

Deployment tooling for the Case Intake classification agent. Owned by the CI/CD story.

These three modules answer deployment questions only: which definition is this, has it changed, get it into the target project, and prove it answers. They take no view on what the agent should contain.

| Module | Does |
|---|---|
| `definition.py` | Reads the manifest, checks the declared assets exist, generates the JSON Schema from the schema model, and fingerprints the assets. No Azure dependency, no credentials, no network. |
| `publish_agent.py` | Publishes into a Foundry project, idempotently. The only module that touches the Foundry SDK. |
| `smoke_test.py` | Invokes the published agent once and checks the answer matches the published schema. |

## The scope boundary

The prompt's content, the taxonomy's shape, which subjects are classifiable, the schema's fields, and how grounding is composed into instructions are **not** decided here. They belong to the agent, taxonomy and evaluation stories.

This is enforced rather than merely stated: the three assets are fingerprinted as opaque bytes, so any change to any of them produces a new agent version without this code understanding a single field inside them. Where the rendered instruction text is needed in order to publish, it is obtained from a seam the agent story owns, not composed here.

## The fingerprint

A twelve-character digest over the manifest's identity fields plus a hash of each asset's bytes. It is what makes publishing idempotent: the fingerprint is written into the published agent's description, existing versions are searched for it, and a version is created only when it is absent.

Deliberately excluded: the model deployment name and the project endpoint. The manifest gives those different values per environment, so folding them in would make the same definition fingerprint differently in each one and destroy the promotion story. The model actually used is recorded on the published version instead.

## Running locally

```bash
uv run python -m foundry.deploy.publish_agent --env dev --dry-run
```

Needs no Azure access. Validates the assets, prints the fingerprint, changes nothing. Change any asset and re-run to see the fingerprint move.

To publish for real, sign in first and supply a project endpoint:

```bash
az login
uv run python -m foundry.deploy.publish_agent --env dev --endpoint "https://<account>.services.ai.azure.com/api/projects/<project>"
uv run python -m foundry.deploy.smoke_test  --env dev --endpoint "..."
```

Run the publish twice. The second run must report `unchanged`; if it publishes again, idempotency is broken and `_list_versions` needs correcting before anything else.

## Status

Provisional. Two SDK details could not be pinned to the last keyword from documentation alone and are isolated to one function each, `_sdk_definition` in the publisher and `_invoke` in the smoke test. Both fail loudly and name themselves as the place to fix. Open points are in `docs/foundry-pipeline-notes.md`.

Platform surface validated against Microsoft documentation: 2026-07-29.
