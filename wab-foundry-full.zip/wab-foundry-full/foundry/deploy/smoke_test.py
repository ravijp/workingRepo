"""Invoke the published agent once and check the answer is structurally usable.

SCOPE. This proves a deployment worked. It does not judge accuracy: whether the
agent picks the right subject is the evaluation story's question, measured against
the labelled set, not something a deploy step can or should assert.

So the checks here are deliberately generic. The answer is validated against the
JSON Schema the definition already carries, rather than against a hard-coded list
of fields. Nothing in this file knows what the agent's fields are called, which
means it keeps working as the schema evolves under another story.

    python -m foundry.deploy.smoke_test --env dev

STATUS: provisional. The invocation surface is the part of the SDK that moved most
recently, so it is isolated in `_invoke`. See docs/foundry-pipeline-notes.md.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path
from typing import Any

from .definition import build, environment_binding, repo_root
from .publish_agent import _credential

# A synthetic request. Deliberately mundane, and written with bracketed
# placeholder tokens because that is the shape the orchestrator will send once
# redaction is in place upstream.
SAMPLE = (
    "Subject: Address update for our association\n\n"
    "Hello,\n\n"
    "Please update the mailing address on file for [ORGANISATION] to [ADDRESS]. "
    "Statements are being returned to sender. Account reference [ACCOUNT].\n\n"
    "Thank you,\n[NAME]\n"
)


class SmokeFailure(RuntimeError):
    """The published agent did not behave usably."""


def _invoke(endpoint: str, agent_name: str, text: str) -> str:
    """Send one message to the published agent and return its text answer."""
    from azure.ai.projects import AIProjectClient

    client = AIProjectClient(endpoint=endpoint, credential=_credential())
    try:
        agent = client.agents.get_client(agent_name=agent_name)
        result = agent.responses.create(input=[{"role": "user", "content": text}])
    except AttributeError as exc:
        raise SmokeFailure(
            "the installed azure-ai-projects does not expose the invocation surface "
            "this uses. Correct _invoke in this file to match the installed SDK. "
            "The publish step is unaffected."
        ) from exc

    answer = getattr(result, "output_text", None)
    if not answer:
        raise SmokeFailure(f"the agent returned no text output: {result!r}")
    return answer


def validate(answer_text: str, schema: dict[str, Any]) -> dict[str, Any]:
    """Check the answer against the schema the definition carries.

    A deliberately small subset of JSON Schema: the parts that tell us structured
    output is actually in force. Full schema validation would need a dependency
    for no extra signal at this stage.
    """
    try:
        answer = json.loads(answer_text)
    except json.JSONDecodeError as exc:
        raise SmokeFailure(
            "the answer is not valid JSON, so structured output is not in force. "
            f"{exc}\nfirst 400 characters: {answer_text[:400]}"
        ) from exc

    if not isinstance(answer, dict):
        raise SmokeFailure(f"the answer is not a JSON object: {type(answer).__name__}")

    properties: dict[str, Any] = schema.get("properties", {})
    required = schema.get("required", [])

    missing = [field for field in required if field not in answer]
    if missing:
        raise SmokeFailure(f"the answer is missing required fields: {', '.join(missing)}")

    if schema.get("additionalProperties") is False:
        extra = [key for key in answer if key not in properties]
        if extra:
            raise SmokeFailure(
                f"the answer carries fields outside the schema: {', '.join(extra)}"
            )

    defs = schema.get("$defs", {})
    for field, spec in properties.items():
        if field not in answer:
            continue
        value = answer[field]

        # Resolve a one-level $ref, which is how a reused enum is emitted.
        ref = spec.get("$ref")
        if ref and ref.startswith("#/$defs/"):
            spec = {**defs.get(ref.split("/")[-1], {}), **{k: v for k, v in spec.items() if k != "$ref"}}

        if "enum" in spec and value not in spec["enum"]:
            shown = spec["enum"] if len(spec["enum"]) <= 8 else spec["enum"][:8] + ["..."]
            raise SmokeFailure(
                f"{field}={value!r} is not one of the permitted values ({shown}), "
                "so the schema is not being enforced"
            )
        if spec.get("type") == "number" or spec.get("type") == "integer":
            if not isinstance(value, (int, float)) or isinstance(value, bool):
                raise SmokeFailure(f"{field}={value!r} is not a number")
            if "minimum" in spec and value < spec["minimum"]:
                raise SmokeFailure(f"{field}={value} is below the minimum {spec['minimum']}")
            if "maximum" in spec and value > spec["maximum"]:
                raise SmokeFailure(f"{field}={value} is above the maximum {spec['maximum']}")
        if spec.get("type") == "boolean" and not isinstance(value, bool):
            raise SmokeFailure(f"{field}={value!r} is not a boolean")
        if spec.get("type") == "string" and (not isinstance(value, str) or not value.strip()):
            raise SmokeFailure(f"{field} is empty or not a string")

    return answer


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    parser.add_argument("--env", required=True)
    parser.add_argument("--endpoint", default=os.environ.get("FOUNDRY_PROJECT_ENDPOINT"))
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)

    root = repo_root()
    definition = build(root)

    endpoint = args.endpoint
    if not endpoint:
        try:
            endpoint = environment_binding(root, args.env).get("project_endpoint")
        except Exception:  # noqa: BLE001 - reported immediately below
            endpoint = None
    if not endpoint or endpoint.startswith("${"):
        print(
            "##vso[task.logissue type=error]no usable project endpoint; pass "
            "--endpoint or set FOUNDRY_PROJECT_ENDPOINT",
            flush=True,
        )
        return 2

    try:
        raw = _invoke(endpoint, definition.name, SAMPLE)
        answer = validate(raw, definition.response_schema)
    except SmokeFailure as exc:
        print(f"##vso[task.logissue type=error]Smoke test failed: {exc}", flush=True)
        return 3
    except Exception as exc:  # noqa: BLE001 - classified for a usable message
        status = getattr(exc, "status_code", None)
        hint = ""
        if status == 403:
            hint = " Invoking needs at least the Foundry Agent Consumer role."
        elif status == 400:
            hint = (
                " A 400 on this sample may mean the content filter rejected the "
                "input. That is a finding rather than a test defect: production "
                "traffic of the same shape would be rejected too."
            )
        print(
            f"##vso[task.logissue type=error]Invocation failed"
            f"{f' ({status})' if status else ''}.{hint} Detail: {exc}",
            flush=True,
        )
        return 4

    print(json.dumps(answer, indent=2), flush=True)
    print(
        f"{definition.name}@{definition.definition_hash} [{args.env}]: "
        "smoke test passed, the answer matches the published schema",
        flush=True,
    )
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(answer, indent=2), encoding="utf-8")
    return 0


if __name__ == "__main__":
    sys.exit(main())
