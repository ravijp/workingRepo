"""Promote a published agent definition from one environment to the next.

Promotion here means: take the definition that is live in the lower environment,
prove it is the one currently in the repository, and publish that same definition
into the higher environment's Foundry project.

That is the only shape available. A Foundry agent version belongs to the project
it was created in, so a version cannot be moved between environments the way a
build artifact can. What can be guaranteed is that the definition is identical,
and the fingerprint is what proves it: the same definition produces the same
fingerprint, so finding that fingerprint already present in the target is proof
the promotion is a no-op.

    python -m foundry.deploy.promote_agent --from dev --to qa
    python -m foundry.deploy.promote_agent --from dev --to qa --dry-run

ON ROLLBACK. Versions are immutable and earlier ones are never deleted, so
recovering a previous definition means pointing the runtime at an earlier version.
The runtime currently resolves the agent by name rather than pinning a version, so
that lever does not exist yet; `--check` reports what is present so the decision
can be made with real information. Wiring an explicit version pin is a separate
decision, recorded in docs/foundry-pipeline-notes.md.
"""

from __future__ import annotations

import argparse
import json
import sys

from .definition import DefinitionError, build, environment_binding, repo_root
from .publish_agent import PublishError, _client, _existing, _label, publish


def _endpoint_for(root, env: str) -> str:
    binding = environment_binding(root, env)
    endpoint = binding.get("project_endpoint", "")
    if not endpoint or endpoint.startswith("${"):
        raise PublishError(
            f"the manifest gives no resolved project_endpoint for '{env}'. "
            "Supply it from the environment's variable group, or pass the "
            "endpoint explicitly."
        )
    return endpoint


def present_in(env: str, endpoint: str, fingerprint: str, agent_name: str) -> str | None:
    """The version carrying this fingerprint in that environment, if any."""
    client = _client(endpoint)
    found = _existing(client, agent_name, fingerprint)
    return _label(found) if found is not None else None


def promote(source: str, target: str, dry_run: bool) -> dict:
    root = repo_root()
    definition = build(root)

    result = {
        "agent_name": definition.name,
        "definition_fingerprint": definition.definition_hash,
        "source": source,
        "target": target,
    }

    source_endpoint = _endpoint_for(root, source)
    in_source = present_in(source, source_endpoint, definition.definition_hash, definition.name)
    result["source_version"] = in_source

    if in_source is None:
        raise PublishError(
            f"the definition in the repository (fingerprint "
            f"{definition.definition_hash}) is not published in '{source}'. Promote "
            "what is actually running: publish to the lower environment first, or "
            "check out the commit whose definition is live there."
        )

    target_endpoint = _endpoint_for(root, target)
    already = present_in(target, target_endpoint, definition.definition_hash, definition.name)
    if already is not None:
        result["action"] = "unchanged"
        result["target_version"] = already
        return result

    if dry_run:
        result["action"] = "dry-run"
        result["target_version"] = None
        return result

    published = publish(target, target_endpoint, None, dry_run=False)
    result["action"] = published["action"]
    result["target_version"] = published.get("version")
    return result


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    parser.add_argument("--from", dest="source", required=True)
    parser.add_argument("--to", dest="target", required=True)
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument(
        "--check",
        action="store_true",
        help="Report what is present in both environments and change nothing.",
    )
    args = parser.parse_args(argv)

    try:
        if args.check:
            root = repo_root()
            definition = build(root)
            report = {
                "agent_name": definition.name,
                "definition_fingerprint": definition.definition_hash,
                args.source: present_in(
                    args.source, _endpoint_for(root, args.source),
                    definition.definition_hash, definition.name,
                ),
                args.target: present_in(
                    args.target, _endpoint_for(root, args.target),
                    definition.definition_hash, definition.name,
                ),
            }
            print(json.dumps(report, indent=2), flush=True)
            return 0

        result = promote(args.source, args.target, args.dry_run)
    except (DefinitionError, PublishError) as exc:
        print(f"##vso[task.logissue type=error]{exc}", flush=True)
        return 2
    except Exception as exc:  # noqa: BLE001 - classified for a usable message
        status = getattr(exc, "status_code", None)
        hint = " Publishing needs the Foundry User role on the target project." if status == 403 else ""
        print(
            f"##vso[task.logissue type=error]Promotion failed"
            f"{f' ({status})' if status else ''}.{hint} Detail: {exc}",
            flush=True,
        )
        return 3

    print(json.dumps(result, indent=2), flush=True)
    said = {
        "created": f"published into {result['target']} as version {result.get('target_version')}",
        "unchanged": f"already present in {result['target']} as version {result.get('target_version')}",
        "dry-run": f"would publish into {result['target']}",
    }.get(result["action"], result["action"])
    print(
        f"{result['agent_name']}@{result['definition_fingerprint']} "
        f"{result['source']} -> {result['target']}: {said}",
        flush=True,
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
