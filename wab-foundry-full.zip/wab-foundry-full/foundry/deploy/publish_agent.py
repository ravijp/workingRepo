"""Publish the Case Intake agent into a Foundry project, idempotently.

SCOPE. This is deployment tooling. It publishes whatever definition the agent
assets describe; it takes no view on what that definition should contain. The
prompt, the schema, the taxonomy and how they combine are other stories' work,
resolved by `definition.resolve_instructions`, which defers to the agent
story''s composer when one exists and uses the prompt file as written otherwise.

    python -m foundry.deploy.publish_agent --env dev --dry-run
    python -m foundry.deploy.publish_agent --env dev

Idempotency. The definition fingerprint is written into the published agent's
description as a marker. Before publishing, existing versions are listed and
searched for that marker; if it is present, nothing is created. So re-running a
stage is a no-op, and promoting an unchanged definition into a higher environment
is also a no-op.

Keyless throughout. Inside an AzureCLI task the sign-in the task performs is what
the credential picks up. Nothing here reads a key, a secret, or a connection
string.

STATUS: provisional. This is a first working shape for the CI/CD story, built to
learn what the pipeline needs rather than to settle how agents are deployed. The
open points, and the alternatives that would change this materially, are listed
in docs/foundry-pipeline-notes.md.

Platform surface validated against Microsoft documentation: 2026-07-29.
  azure-ai-projects 2.4.0 (generally available)
  AIProjectClient(endpoint=..., credential=...)
  client.agents.create_version(agent_name=..., definition=PromptAgentDefinition(...))
  structured output rides definition.text.format, not a response_format argument
Two details could not be pinned to the last keyword from documentation alone and
are each isolated to one function, `_sdk_definition` and `_list_versions`, so
there is a single place to correct. Both fail loudly rather than guessing.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

from .definition import (
    DefinitionError,
    build,
    environment_binding,
    read_manifest,
    repo_root,
)
from .guardrail_check import GuardrailRisk, assert_clean

MARKER_PREFIX = "definition-fingerprint:"


class PublishError(RuntimeError):
    """The agent could not be published."""


def _marker(fingerprint: str) -> str:
    return f"[{MARKER_PREFIX}{fingerprint}]"


def _credential():
    """A keyless credential.

    Named explicitly rather than relying on chain ordering: inside an AzureCLI
    task the CLI has already signed in with the service connection's federated
    identity. Set FOUNDRY_USE_DEFAULT_CREDENTIAL=1 for a managed-identity agent,
    where the full chain is needed instead.
    """
    if os.environ.get("FOUNDRY_USE_DEFAULT_CREDENTIAL") == "1":
        from azure.identity import DefaultAzureCredential

        return DefaultAzureCredential(exclude_interactive_browser_credential=True)
    from azure.identity import AzureCliCredential

    return AzureCliCredential(process_timeout=60)


def _client(endpoint: str):
    from azure.ai.projects import AIProjectClient

    return AIProjectClient(endpoint=endpoint, credential=_credential())


def _sdk_definition(model: str, instructions: str, description: str, schema: dict):
    """Translate into the SDK's object graph. One place to correct on SDK drift."""
    from azure.ai.projects.models import (
        PromptAgentDefinition,
        PromptAgentDefinitionTextOptions,
        TextResponseFormatJsonSchema,
    )

    return PromptAgentDefinition(
        model=model,
        instructions=instructions,
        description=description,
        text=PromptAgentDefinitionTextOptions(
            format=TextResponseFormatJsonSchema(
                name="CaseIntakeClassification",
                schema=schema,
                strict=True,
            )
        ),
    )


def _list_versions(client, agent_name: str):
    """Existing versions, or an empty list if the agent has never been published.

    A not-found response is a normal first run. Any other failure is raised:
    treating an API error as "no versions" would publish a duplicate every time.
    """
    from azure.core.exceptions import HttpResponseError

    try:
        return list(client.agents.list_versions(agent_name=agent_name))
    except HttpResponseError as exc:
        if exc.status_code == 404:
            return []
        raise
    except AttributeError as exc:
        raise PublishError(
            "the installed azure-ai-projects does not expose "
            "client.agents.list_versions(agent_name=...). Idempotency depends on "
            "listing versions, so correct _list_versions in this file to match "
            "the installed SDK before running again."
        ) from exc


def _existing(client, agent_name: str, fingerprint: str):
    marker = _marker(fingerprint)
    for version in _list_versions(client, agent_name):
        description = (
            getattr(getattr(version, "definition", None), "description", None)
            or getattr(version, "description", None)
            or ""
        )
        if marker in description:
            return version
    return None


def _label(version) -> str:
    for attribute in ("version", "id", "name"):
        value = getattr(version, attribute, None)
        if value:
            return str(value)
    return "unknown"


def publish(env: str, endpoint: str | None, model: str | None, dry_run: bool) -> dict:
    root = repo_root()
    manifest = read_manifest(root)
    definition = build(root)

    binding = {}
    try:
        binding = environment_binding(root, env)
    except DefinitionError:
        # An environment the manifest does not declare is fine for a dry run;
        # publishing without a binding is not, and is caught below.
        pass

    model = model or binding.get("model_deployment")
    endpoint = endpoint or os.environ.get("FOUNDRY_PROJECT_ENDPOINT")

    result = {
        "environment": env,
        "agent_name": definition.name,
        "definition_fingerprint": definition.definition_hash,
        "prompt_version": definition.prompt_version,
        "instructions_source": definition.instructions_source,
        "model_deployment": model,
    }

    if dry_run:
        result["action"] = "dry-run"
        result["version"] = None
        return result

    if not endpoint:
        raise PublishError(
            "no project endpoint. Pass --endpoint, set FOUNDRY_PROJECT_ENDPOINT, or "
            f"declare parameter_values.{env}.project_endpoint in the manifest."
        )
    if not model:
        raise PublishError(
            f"no model deployment for '{env}'. Pass --model or declare "
            f"parameter_values.{env}.model_deployment in the manifest."
        )

    # The prompt passes through the same content filter as an email does. A
    # pattern that reads as personal information gets the publish rejected, or
    # gets the agent published and then every invocation blocked. Checked here so
    # the failure lands next to its cause.
    assert_clean(definition.instructions, "the instruction text about to be published")

    instructions = definition.instructions
    description = f"Case Intake classification agent. {_marker(definition.definition_hash)}"

    client = _client(endpoint)
    already = _existing(client, definition.name, definition.definition_hash)
    if already is not None:
        result["action"] = "unchanged"
        result["version"] = _label(already)
        return result

    created = client.agents.create_version(
        agent_name=definition.name,
        definition=_sdk_definition(
            model, instructions, description, definition.response_schema
        ),
    )
    result["action"] = "created"
    result["version"] = _label(created)
    return result


def _emit(name: str, value: str) -> None:
    print(f"##vso[task.setvariable variable={name};isOutput=true]{value}")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    parser.add_argument("--env", required=True, help="Environment key in the manifest.")
    parser.add_argument("--endpoint", default=None)
    parser.add_argument("--model", default=None)
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)

    try:
        result = publish(args.env, args.endpoint, args.model, args.dry_run)
    except DefinitionError as exc:
        print(f"##vso[task.logissue type=error]Agent assets invalid: {exc}", flush=True)
        return 2
    except GuardrailRisk as exc:
        print(f"##vso[task.logissue type=error]{exc}", flush=True)
        return 6
    except PublishError as exc:
        print(f"##vso[task.logissue type=error]{exc}", flush=True)
        return 3
    except Exception as exc:  # noqa: BLE001 - classified below for a usable message
        status = getattr(exc, "status_code", None)
        hint = ""
        if status == 403:
            hint = (
                " Authenticated but not authorised. Publishing needs the Foundry "
                "User role on the target project."
            )
        elif status == 401:
            hint = (
                " Not authenticated. This step must run inside an AzureCLI task on "
                "a workload-identity service connection."
            )
        print(
            f"##vso[task.logissue type=error]Publish failed"
            f"{f' ({status})' if status else ''}.{hint} Detail: {exc}",
            flush=True,
        )
        return 4

    print(json.dumps(result, indent=2), flush=True)
    _emit("agentDefinitionFingerprint", result["definition_fingerprint"])
    _emit("agentAction", result["action"])
    if result.get("version"):
        _emit("agentVersion", result["version"])
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=2), encoding="utf-8")

    said = {
        "created": f"published as version {result.get('version')}",
        "unchanged": f"already present as version {result.get('version')}, nothing to do",
        "dry-run": "validated and fingerprinted, nothing published",
    }[result["action"]]
    print(
        f"{result['agent_name']}@{result['definition_fingerprint']} "
        f"[{result['environment']}]: {said}",
        flush=True,
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
