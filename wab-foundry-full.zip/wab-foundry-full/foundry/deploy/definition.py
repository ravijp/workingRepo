"""Resolve and fingerprint the agent definition for deployment.

SCOPE. This belongs to the CI/CD story. It answers one question: "which exact
agent definition is this, and has it changed?" It does not decide what a good
prompt is, which subjects are classifiable, how the taxonomy is shaped, or how
grounding is composed. Those belong to the agent, taxonomy and evaluation
stories, which are being worked on in parallel.

SELF-SUFFICIENT BY DESIGN. This is the first story worked in the repository, so
nothing here depends on another story's file existing. The instruction text sent
to Foundry is the prompt file the manifest names, used as written. If the agent
story later introduces a module that composes the prompt with grounding, this
picks it up automatically; until then the prompt stands on its own and the
pipeline runs.

WHAT THE FINGERPRINT COVERS. Exactly what is published: the resolved instruction
text and the generated JSON Schema, plus the agent's identity from the manifest.
Hashing the resolved instructions rather than the individual asset files means the
fingerprint always describes what was actually sent. When grounding is eventually
composed into the instructions, it enters the fingerprint automatically because it
is inside the text; while it is not composed in, a taxonomy edit correctly does
not produce a new agent version, because the published agent would be identical.

Deliberately excluded: the model deployment name and the project endpoint. The
manifest gives those different values per environment, so folding them in would
make one definition fingerprint differently in each environment and destroy the
promotion story. The model in force is recorded on the published version instead.
"""

from __future__ import annotations

import hashlib
import importlib.util
import json
import os
import re
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any

# Bump only when the fingerprint's composition changes. A bump changes every
# fingerprint and forces one new version per environment on the next run.
CANONICAL_FORM_VERSION = 1

HASH_LENGTH = 12

# The optional seam. If the agent story provides this module and function, the
# instruction text comes from it. Its absence is normal and not an error.
RENDERER_MODULE = "foundry/agent/agent_definition.py"
RENDERER_FUNCTION = "build_instructions"

INSTRUCTIONS_FROM_PROMPT = "prompt"
INSTRUCTIONS_FROM_RENDERER = "renderer"


class DefinitionError(RuntimeError):
    """The checked-in assets do not describe a publishable agent."""


@dataclass(frozen=True)
class AgentDefinition:
    name: str
    kind: str
    prompt_version: str
    instructions: str
    instructions_source: str
    response_schema: dict[str, Any]
    definition_hash: str
    canonical: dict[str, Any]


def repo_root() -> Path:
    """The repository root, two levels above this file (foundry/deploy/...)."""
    return Path(__file__).resolve().parent.parent.parent


def _sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _load_module(path: Path, module_name: str):
    spec = importlib.util.spec_from_file_location(module_name, path)
    if spec is None or spec.loader is None:
        raise DefinitionError(f"could not load module: {path}")
    module = importlib.util.module_from_spec(spec)
    # Register before executing: a module using postponed annotation evaluation
    # (which the schema does) resolves its forward references by looking itself up
    # in sys.modules. Without this, Pydantic reports the model as not fully
    # defined and schema generation fails.
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module


def read_manifest(root: Path) -> dict[str, Any]:
    """Read the agent manifest.

    The JSON mirror is read rather than the YAML, because no YAML library is a
    repository dependency. Edit the .yaml for humans; this reads the .json.
    """
    path = root / "foundry" / "agent" / "agent.manifest.json"
    if not path.is_file():
        raise DefinitionError(
            f"manifest not found: {path}. It declares which prompt, schema and "
            "grounding the agent is built from, so deployment cannot proceed "
            "without it."
        )
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise DefinitionError(f"manifest is not valid JSON ({path}): {exc}") from exc
    for field in ("name", "kind", "prompt_version", "schema_ref", "grounding_ref"):
        if field not in data:
            raise DefinitionError(f"manifest is missing '{field}': {path}")
    return data


def prompt_path(root: Path, manifest: dict[str, Any]) -> Path:
    return root / "foundry" / "prompts" / f"{manifest['prompt_version']}.txt"


def _read_prompt(root: Path, manifest: dict[str, Any]) -> str:
    path = prompt_path(root, manifest)
    if not path.is_file():
        raise DefinitionError(
            f"prompt not found: {path}. The manifest names prompt_version "
            f"'{manifest['prompt_version']}', so a file of that name must exist "
            "in foundry/prompts/."
        )
    text = path.read_text(encoding="utf-8")
    if not text.strip():
        raise DefinitionError(
            f"the prompt file is empty: {path}. An agent cannot be published "
            "without instructions. Add the prompt text, or point the manifest's "
            "prompt_version at a file that has content."
        )
    return text


def generate_schema(root: Path, schema_ref: str) -> dict[str, Any]:
    """Produce the JSON Schema from the model the manifest names.

    Generated rather than hand-copied, so the answer contract has exactly one
    definition in the repository. The schema's content is the agent story's
    business; this only converts it into the form Foundry wants.
    """
    try:
        rel_path, class_name = schema_ref.split("::", 1)
    except ValueError as exc:
        raise DefinitionError(
            f"schema_ref must be 'path::ClassName', got {schema_ref!r}"
        ) from exc

    module_path = root / rel_path
    if not module_path.is_file():
        raise DefinitionError(f"schema module not found: {module_path}")

    module = _load_module(module_path, "_case_intake_schema")
    model = getattr(module, class_name, None)
    if model is None:
        raise DefinitionError(f"{module_path} defines no {class_name}")
    if not hasattr(model, "model_json_schema"):
        raise DefinitionError(
            f"{class_name} is not a Pydantic v2 model; it has no model_json_schema()"
        )
    try:
        model.model_rebuild()
        return model.model_json_schema()
    except Exception as exc:  # noqa: BLE001 - re-raised with context
        raise DefinitionError(
            f"could not generate a JSON Schema from {class_name}: {exc}"
        ) from exc


def resolve_instructions(root: Path, manifest: dict[str, Any]) -> tuple[str, str]:
    """The instruction text to publish, and where it came from.

    Two sources, in order of preference:

      1. The agent story's composer, if it exists. Deciding how the prompt and the
         grounding come together is agent-design work; when that module appears,
         the pipeline defers to it rather than competing with it.
      2. The prompt file, as written. This is the default and needs nothing beyond
         the prompt itself, which is what makes this story runnable on its own.
    """
    module_path = root / RENDERER_MODULE
    if module_path.is_file():
        module = _load_module(module_path, "_case_intake_agent_definition")
        renderer = getattr(module, RENDERER_FUNCTION, None)
        if renderer is not None:
            # Any failure inside the composer is reported as a definition problem,
            # so the pipeline classifies it as bad assets rather than as an
            # unexpected crash. Without this the exception type is whatever the
            # composer chose to raise, which the caller cannot reason about.
            try:
                text = renderer(manifest)
            except DefinitionError:
                raise
            except Exception as exc:  # noqa: BLE001 - re-raised with context
                raise DefinitionError(
                    f"{RENDERER_MODULE}::{RENDERER_FUNCTION} failed to compose the "
                    f"instructions: {type(exc).__name__}: {exc}"
                ) from exc
            if not isinstance(text, str) or not text.strip():
                raise DefinitionError(
                    f"{RENDERER_MODULE}::{RENDERER_FUNCTION} returned no instruction "
                    "text. Either return the composed instructions, or remove the "
                    "function so the prompt file is used directly."
                )
            return text, INSTRUCTIONS_FROM_RENDERER

    return _read_prompt(root, manifest), INSTRUCTIONS_FROM_PROMPT


def build(root: Path | None = None) -> AgentDefinition:
    """Resolve the definition and fingerprint it.

    Needs no credentials and no network, which is why it runs in the build stage
    and in the tests.
    """
    root = root or repo_root()
    manifest = read_manifest(root)

    # Validated because the manifest declares it, even though it only reaches the
    # published agent once the composer in resolve_instructions exists. A manifest
    # pointing at a missing file is a defect either way.
    grounding = root / manifest["grounding_ref"]
    if not grounding.is_file():
        raise DefinitionError(
            f"the manifest's grounding_ref does not exist: {grounding}"
        )

    schema = generate_schema(root, manifest["schema_ref"])
    instructions, source = resolve_instructions(root, manifest)

    canonical = {
        "canonical_form_version": CANONICAL_FORM_VERSION,
        "name": manifest["name"],
        "kind": manifest["kind"],
        "prompt_version": manifest["prompt_version"],
        "instructions_sha256": _sha256(instructions.encode("utf-8")),
        "schema_sha256": _sha256(
            json.dumps(schema, sort_keys=True, separators=(",", ":")).encode("utf-8")
        ),
    }

    blob = json.dumps(canonical, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
    digest = _sha256(blob.encode("utf-8"))[:HASH_LENGTH]

    return AgentDefinition(
        name=manifest["name"],
        kind=manifest["kind"],
        prompt_version=manifest["prompt_version"],
        instructions=instructions,
        instructions_source=source,
        response_schema=schema,
        definition_hash=digest,
        canonical=canonical,
    )


_VARIABLE = re.compile(r"^\$\{([A-Z0-9_]+)\}$")


def environment_binding(root: Path | None, env: str) -> dict[str, str]:
    """The per-environment values, deliberately not part of the fingerprint.

    A value written as ${VARIABLE} in the manifest has no default and is read from
    the environment instead. That is how the pipeline supplies values: each
    environment's variable group sets them on the build agent. A literal value is
    a default, so a local run needs no setup.

    An unresolved variable comes back as an empty string rather than raising, so
    the caller can report which specific thing is missing and why.
    """
    root = root or repo_root()
    manifest = read_manifest(root)
    values = manifest.get("parameter_values", {})
    if env not in values:
        raise DefinitionError(
            f"the manifest declares no parameter_values for '{env}'. "
            f"Known environments: {', '.join(sorted(values)) or 'none'}"
        )
    resolved: dict[str, str] = {}
    for key, value in values[env].items():
        match = _VARIABLE.match(str(value).strip())
        resolved[key] = os.environ.get(match.group(1), "") if match else str(value)
    return resolved
