"""The one answer shape the classifier returns for one email.

Six fields: the subject code, the priority, a banker-readable summary, a confidence
value, the reasoning, and whether the email is actual work at all.

The permitted subject codes are NOT written here. They are generated into
`subject_codes.py` from the subject source, so the list has exactly one home and
the prompt and the schema cannot disagree about what the model may return.
Regenerate both with:

    python -m foundry.knowledge.refresh_subject_reference

Every field is required and no extra fields are permitted, because Foundry
publishes this in strict mode and the orchestrator's parser depends on the same
shape.
"""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

try:
    from .subject_codes import SubjectCode
except ImportError:
    # This module is deliberately also loadable by file path, because the
    # deployment tooling reads it that way so it works from a pipeline working
    # directory without the package having been installed. Loaded that way there
    # is no package context, so the relative import above cannot resolve and the
    # sibling is loaded by path instead. Both routes yield the same object.
    import importlib.util as _importlib_util
    import pathlib as _pathlib
    import sys as _sys

    _codes_path = _pathlib.Path(__file__).with_name("subject_codes.py")
    _spec = _importlib_util.spec_from_file_location("_case_intake_subject_codes", _codes_path)
    if _spec is None or _spec.loader is None:  # pragma: no cover - unreachable in practice
        raise
    _codes = _importlib_util.module_from_spec(_spec)
    _sys.modules["_case_intake_subject_codes"] = _codes
    _spec.loader.exec_module(_codes)
    SubjectCode = _codes.SubjectCode


class ClassificationOutput(BaseModel):
    """The classifier's answer for a single email."""

    model_config = ConfigDict(extra="forbid")

    category: SubjectCode = Field(
        description=(
            "The subject this email belongs to, from the agreed subject list."
        )
    )

    priority: Literal["High", "Normal"] = Field(
        description=(
            "High only when the email itself shows urgency. There is no Low band; "
            "the integration layer maps these two values onto the wire codes."
        )
    )

    description: str = Field(
        min_length=1,
        description=(
            "A short summary of what is being asked, written for the banker who "
            "picks up the case. The input is redacted, so this describes the "
            "request rather than the requester or the account."
        ),
    )

    confidence: float = Field(
        ge=0.0,
        le=1.0,
        description=(
            "A ranking signal from 0 to 1, not a calibrated probability. The "
            "decision gate compares it against a threshold set from measurement."
        ),
    )

    reasoning: str = Field(
        min_length=1,
        description=(
            "One or two sentences naming what in the email decided the subject. "
            "Read during error analysis; not shown to bankers."
        ),
    )

    is_actual_work: bool = Field(
        description=(
            "False when the email is not actual work: an automatic reply, an "
            "out-of-office notice, a delivery report, a meeting response, or spam. "
            "This is the model's judgment rather than an upstream filter."
        )
    )
