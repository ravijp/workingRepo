"""Case Intake answer schema: the ClassificationOutput contract and the subject vocabulary.

Moved out of core/ (was core/classification/classification_output.py): both the
category vocabulary and the answer shape are Case Intake's, not shared, so they
live in the agent. core/grounding is the shared pipe; this is the agent's cargo.
"""
