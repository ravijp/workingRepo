"""Compose the agent's instruction text from the prompt and the subject reference.

This is the agent story's side of the seam the deployment tooling calls. The
tooling asks for `build_instructions(manifest)` and publishes whatever comes back;
how the prompt and the grounding come together is decided here.

WHY THE GROUNDING IS RENDERED IN, NOT RETRIEVED. The taxonomy was measured against
the model's context window and found small enough to pass in full, so the whole
subject list goes into the prompt and no retrieval layer is built. That keeps the
classification a single grounded call.

THE WHOLE LIST IS OFFERED. Every subject in the reference is a valid answer. Where
two subjects overlap, the descriptions carry the boundary and tell the model which
to prefer, so disambiguation is a matter of wording rather than of withholding
options.

`EXCLUDED_CODES` and the exclusions file are the way to withdraw a subject without
regenerating anything, which is what a mid-sprint correction needs.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

# Codes the model must never return. Populate this, or supply
# foundry/knowledge/subject_exclusions.json, once the filtered list is agreed.
# Both feed the same filter, so there is one behaviour and two ways to express it.
EXCLUDED_CODES: set[str] = set()

EXCLUSIONS_FILE = "foundry/knowledge/subject_exclusions.json"

SUBJECT_PLACEHOLDER = "{{SUBJECT_LIST}}"


class CompositionError(RuntimeError):
    """The instruction text could not be composed."""


def _repo_root() -> Path:
    return Path(__file__).resolve().parent.parent.parent


def load_subjects(root: Path | None = None, grounding_ref: str | None = None) -> list[dict[str, Any]]:
    """Read the subject reference."""
    root = root or _repo_root()
    path = root / (grounding_ref or "foundry/knowledge/subject_reference.jsonl")
    if not path.is_file():
        raise CompositionError(f"subject reference not found: {path}")
    rows: list[dict[str, Any]] = []
    for number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        line = line.strip()
        if not line:
            continue
        try:
            row = json.loads(line)
        except json.JSONDecodeError as exc:
            raise CompositionError(f"{path}:{number}: not valid JSON: {exc}") from exc
        for field in ("code", "title"):
            if field not in row:
                raise CompositionError(f"{path}:{number}: row is missing '{field}'")
        rows.append(row)
    if not rows:
        raise CompositionError(f"subject reference is empty: {path}")
    return rows


def load_exclusions(root: Path | None = None) -> set[str]:
    """Codes to withhold from the model, from the module constant and the file."""
    root = root or _repo_root()
    excluded = set(EXCLUDED_CODES)
    path = root / EXCLUSIONS_FILE
    if path.is_file():
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as exc:
            raise CompositionError(f"{path}: not valid JSON: {exc}") from exc
        if isinstance(data, dict):
            data = data.get("excluded_codes", [])
        if not isinstance(data, list):
            raise CompositionError(
                f"{path}: expected a list of codes, or an object with 'excluded_codes'"
            )
        excluded |= {str(code) for code in data}
    return excluded


def selectable(root: Path | None = None, grounding_ref: str | None = None) -> list[dict[str, Any]]:
    """The subjects the model may choose from: the whole list, minus any exclusions."""
    rows = load_subjects(root, grounding_ref)
    excluded = load_exclusions(root)
    keep = [row for row in rows if row["code"] not in excluded]
    if not keep:
        raise CompositionError(
            "every subject is excluded, so the model would have nothing to choose. "
            f"Check {EXCLUSIONS_FILE} and EXCLUDED_CODES."
        )
    return keep


def render_subject_block(subjects: list[dict[str, Any]]) -> str:
    """Format the subject list for the prompt.

    Each subject carries whatever guidance the export provides. The definition,
    the use-when and the not-for lines are what make a subject distinguishable
    from its neighbours, so they are included where present: early accuracy work
    is expected to turn on sharpening exactly these.
    """
    blocks: list[str] = []
    for row in subjects:
        lines = [f"- {row['code']}: {row['title']}"]
        for field, label in (("definition", "Definition"),):
            value = row.get(field)
            if value and str(value).strip():
                lines.append(f"    {label}: {str(value).strip()}")
        blocks.append("\n".join(lines))
    return "\n".join(blocks)


def build_instructions(manifest: dict[str, Any], root: Path | None = None) -> str:
    """The seam the deployment tooling calls.

    Returns the prompt with the subject list substituted in. The prompt must carry
    the placeholder exactly once; a prompt without it would silently publish an
    agent that has no subject list at all, which is worse than failing here.
    """
    root = root or _repo_root()
    prompt_version = manifest.get("prompt_version")
    if not prompt_version:
        raise CompositionError("the manifest declares no prompt_version")

    prompt_path = root / "foundry" / "prompts" / f"{prompt_version}.txt"
    if not prompt_path.is_file():
        raise CompositionError(f"prompt not found: {prompt_path}")
    template = prompt_path.read_text(encoding="utf-8")
    if not template.strip():
        # Guard, not a formality. Without it an empty prompt still composes,
        # because the subject list gets appended, and the agent publishes with
        # nothing but a list of subjects and no instruction to classify against
        # them. That would look like a working deployment and behave badly.
        raise CompositionError(
            f"the prompt file is empty: {prompt_path}. The subject list alone is "
            "not instructions; add the prompt text before publishing."
        )

    subjects = selectable(root, manifest.get("grounding_ref"))
    block = render_subject_block(subjects)

    occurrences = template.count(SUBJECT_PLACEHOLDER)
    if occurrences == 1:
        return template.replace(SUBJECT_PLACEHOLDER, block)
    if occurrences == 0:
        # The prompt does not ask for the list, so append it under a heading
        # rather than dropping it. Publishing an agent with no subject list would
        # make every answer a guess.
        return f"{template.rstrip()}\n\n## Subjects\n\nChoose exactly one code from this list.\n\n{block}\n"
    raise CompositionError(
        f"{prompt_path} contains {SUBJECT_PLACEHOLDER} {occurrences} times; "
        "it must appear at most once"
    )


def subject_codes(root: Path | None = None, grounding_ref: str | None = None) -> list[str]:
    """The codes offered to the model, for cross-checking against the schema."""
    return [row["code"] for row in selectable(root, grounding_ref)]
