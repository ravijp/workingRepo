"""Tests for the instruction composer.

These belong to the agent story rather than the pipeline. They cover the parts of
composition that would silently produce a bad agent: losing the subject list,
offering a subject the schema rejects, or excluding everything.

They deliberately do NOT assert the prompt's wording or how many subjects there
should be, because both are expected to change as the taxonomy and prompt work
proceeds. A test here should fail when composition breaks, not when someone edits
a sentence.
"""

from __future__ import annotations

import importlib.util
import json
import shutil
import sys
from pathlib import Path

import pytest

from foundry.agent import agent_definition as composer
from foundry.agent.agent_definition import CompositionError
from foundry.deploy.definition import build, generate_schema, read_manifest, repo_root

ROOT = repo_root()
MANIFEST = read_manifest(ROOT)


@pytest.fixture
def workspace(tmp_path: Path) -> Path:
    for relative in ("foundry/agent", "foundry/prompts", "foundry/schema", "foundry/knowledge"):
        source = ROOT / relative
        if source.is_dir():
            shutil.copytree(source, tmp_path / relative, dirs_exist_ok=True)
    return tmp_path


def test_the_subject_list_reaches_the_instructions():
    text = composer.build_instructions(MANIFEST, ROOT)
    codes = composer.subject_codes(ROOT)
    assert codes
    for code in codes[:20]:
        assert code in text, f"{code} is offered but never appears in the instructions"


def test_every_offered_subject_is_permitted_by_the_schema():
    """The model must not be offered a subject the schema will reject.

    This is the check that catches the prompt and the response contract drifting
    apart, which produces answers the orchestrator cannot parse.
    """
    schema = generate_schema(ROOT, MANIFEST["schema_ref"])
    category = schema["properties"]["category"]
    if "enum" in category:
        permitted = set(category["enum"])
    else:
        ref = category.get("$ref") or category.get("allOf", [{}])[0].get("$ref")
        permitted = set(schema["$defs"][ref.split("/")[-1]]["enum"])

    offered = set(composer.subject_codes(ROOT))
    unpermitted = sorted(offered - permitted)
    assert not unpermitted, (
        "these subjects are offered to the model but rejected by the schema: "
        f"{unpermitted[:12]}"
    )


def test_excluding_a_subject_removes_it_from_the_instructions(workspace: Path):
    codes = composer.subject_codes(workspace)
    victim = codes[0]
    (workspace / "foundry/knowledge/subject_exclusions.json").write_text(
        json.dumps({"excluded_codes": [victim]}), encoding="utf-8"
    )
    remaining = composer.subject_codes(workspace)
    assert victim not in remaining
    assert len(remaining) == len(codes) - 1


def test_excluding_everything_is_rejected(workspace: Path):
    (workspace / "foundry/knowledge/subject_exclusions.json").write_text(
        json.dumps({"excluded_codes": composer.subject_codes(workspace)}), encoding="utf-8"
    )
    with pytest.raises(CompositionError, match="every subject is excluded"):
        composer.subject_codes(workspace)


def test_a_placeholder_in_the_prompt_is_substituted(workspace: Path):
    prompt = workspace / "foundry/prompts" / f"{MANIFEST['prompt_version']}.txt"
    prompt.write_text(
        "Classify the email.\n\nSubjects:\n{{SUBJECT_LIST}}\n", encoding="utf-8"
    )
    text = composer.build_instructions(MANIFEST, workspace)
    assert "{{SUBJECT_LIST}}" not in text
    assert composer.subject_codes(workspace)[0] in text


def test_a_prompt_without_the_placeholder_still_gets_the_subjects(workspace: Path):
    prompt = workspace / "foundry/prompts" / f"{MANIFEST['prompt_version']}.txt"
    prompt.write_text("Classify the email.\n", encoding="utf-8")
    text = composer.build_instructions(MANIFEST, workspace)
    assert composer.subject_codes(workspace)[0] in text


def test_a_repeated_placeholder_is_rejected(workspace: Path):
    prompt = workspace / "foundry/prompts" / f"{MANIFEST['prompt_version']}.txt"
    prompt.write_text("{{SUBJECT_LIST}} and again {{SUBJECT_LIST}}", encoding="utf-8")
    with pytest.raises(CompositionError, match="at most once"):
        composer.build_instructions(MANIFEST, workspace)


def test_a_malformed_reference_row_is_rejected(workspace: Path):
    path = workspace / MANIFEST["grounding_ref"]
    path.write_text(path.read_text("utf-8") + "{not json}\n", encoding="utf-8")
    with pytest.raises(CompositionError, match="not valid JSON"):
        composer.subject_codes(workspace)


def test_composing_changes_the_published_fingerprint(workspace: Path):
    """Excluding a subject must reach the deployed agent, not just the prompt."""
    before = build(workspace).definition_hash
    (workspace / "foundry/knowledge/subject_exclusions.json").write_text(
        json.dumps({"excluded_codes": [composer.subject_codes(workspace)[0]]}),
        encoding="utf-8",
    )
    assert build(workspace).definition_hash != before
