"""Tests for the deployment tooling.

SCOPE. These cover the CI/CD story's own code: reading the manifest, validating
that declared assets exist, fingerprinting them, and the structural checks the
smoke test applies. They deliberately assert nothing about prompt wording,
taxonomy shape, or which subjects are classifiable, because those belong to other
stories and are actively changing. A test here should not fail because someone
edited the prompt.
"""

from __future__ import annotations

import json
import shutil
from pathlib import Path

import pytest

from foundry.deploy.definition import DefinitionError, build, environment_binding, repo_root
from foundry.deploy.guardrail_check import GuardrailRisk, assert_clean, scan
from foundry.deploy.smoke_test import SmokeFailure, validate

ROOT = repo_root()


@pytest.fixture
def workspace(tmp_path: Path) -> Path:
    """A writable copy of the repository's agent assets."""
    for relative in ("foundry/agent", "foundry/prompts", "foundry/schema", "foundry/knowledge"):
        source = ROOT / relative
        if source.is_dir():
            shutil.copytree(source, tmp_path / relative, dirs_exist_ok=True)
    return tmp_path


# --- fingerprinting -------------------------------------------------------


def test_builds_from_the_repository_assets():
    definition = build(ROOT)
    assert definition.name
    assert len(definition.definition_hash) == 12
    assert set(definition.canonical) >= {"instructions_sha256", "schema_sha256"}
    assert definition.instructions_source in {"prompt", "renderer"}
    assert definition.instructions.strip()


def test_fingerprint_is_stable_across_runs():
    assert build(ROOT).definition_hash == build(ROOT).definition_hash


def test_changing_the_prompt_changes_the_fingerprint(workspace: Path):
    before = build(workspace).definition_hash
    manifest = json.loads((workspace / "foundry/agent/agent.manifest.json").read_text("utf-8"))
    prompt = workspace / "foundry/prompts" / f"{manifest['prompt_version']}.txt"
    prompt.write_text(prompt.read_text("utf-8") + "\nAn additional line.\n", encoding="utf-8")
    assert build(workspace).definition_hash != before


def test_editing_grounding_alone_does_not_change_the_fingerprint(workspace: Path):
    """Grounding is not composed into the instructions yet, so a taxonomy edit
    leaves the published agent identical. Bumping the version would be noise."""
    before = build(workspace).definition_hash
    manifest = json.loads((workspace / "foundry/agent/agent.manifest.json").read_text("utf-8"))
    grounding = workspace / manifest["grounding_ref"]
    grounding.write_text(grounding.read_text("utf-8") + "\n", encoding="utf-8")
    assert build(workspace).definition_hash == before


def test_a_composer_takes_precedence_over_the_prompt(workspace: Path):
    """When a composer exists, the tooling defers to it rather than the prompt.

    Written to hold whether or not a composer is already present, because the
    pipeline must behave the same either way.
    """
    before = build(workspace)
    (workspace / "foundry/agent/agent_definition.py").write_text(
        "def build_instructions(manifest):\n"
        "    return 'composed instructions for ' + manifest['name']\n",
        encoding="utf-8",
    )
    after = build(workspace)
    assert after.instructions_source == "renderer"
    assert after.instructions.startswith("composed instructions for")
    assert after.definition_hash != before.definition_hash


def test_removing_the_composer_falls_back_to_the_prompt(workspace: Path):
    """The prompt alone is enough; no other story's file has to exist."""
    composer = workspace / "foundry/agent/agent_definition.py"
    if composer.exists():
        composer.unlink()
    definition = build(workspace)
    assert definition.instructions_source == "prompt"
    assert definition.instructions.strip()


def test_a_failing_composer_is_reported_as_a_definition_problem(workspace: Path):
    """A composer that raises must not surface as an unclassified crash."""
    (workspace / "foundry/agent/agent_definition.py").write_text(
        "def build_instructions(manifest):\n    raise ValueError('taxonomy broke')\n",
        encoding="utf-8",
    )
    with pytest.raises(DefinitionError, match="failed to compose"):
        build(workspace)


def test_a_composer_returning_nothing_is_rejected(workspace: Path):
    (workspace / "foundry/agent/agent_definition.py").write_text(
        "def build_instructions(manifest):\n    return ''\n", encoding="utf-8"
    )
    with pytest.raises(DefinitionError, match="returned no instruction text"):
        build(workspace)


def test_an_empty_prompt_is_rejected(workspace: Path):
    manifest = json.loads((workspace / "foundry/agent/agent.manifest.json").read_text("utf-8"))
    (workspace / "foundry/prompts" / f"{manifest['prompt_version']}.txt").write_text("", encoding="utf-8")
    with pytest.raises(DefinitionError, match="empty|returned no instruction text"):
        build(workspace)


def test_pointing_at_a_different_prompt_version_changes_the_fingerprint(workspace: Path):
    """The manifest names the prompt; selecting another one is a real change."""
    before = build(workspace).definition_hash
    path = workspace / "foundry/agent/agent.manifest.json"
    manifest = json.loads(path.read_text("utf-8"))
    other = workspace / "foundry/prompts/system_zz_test.txt"
    other.write_text((workspace / "foundry/prompts" / f"{manifest['prompt_version']}.txt").read_text("utf-8"), encoding="utf-8")
    manifest["prompt_version"] = "system_zz_test"
    path.write_text(json.dumps(manifest), encoding="utf-8")
    assert build(workspace).definition_hash != before


# --- failing loudly on bad inputs ----------------------------------------


def test_missing_manifest_is_rejected(tmp_path: Path):
    with pytest.raises(DefinitionError, match="manifest not found"):
        build(tmp_path)


def test_missing_prompt_is_rejected(workspace: Path):
    manifest = json.loads((workspace / "foundry/agent/agent.manifest.json").read_text("utf-8"))
    (workspace / "foundry/prompts" / f"{manifest['prompt_version']}.txt").unlink()
    with pytest.raises(DefinitionError, match="not found|failed to compose"):
        build(workspace)


def test_missing_grounding_is_rejected(workspace: Path):
    manifest = json.loads((workspace / "foundry/agent/agent.manifest.json").read_text("utf-8"))
    (workspace / manifest["grounding_ref"]).unlink()
    with pytest.raises(DefinitionError, match="grounding_ref does not exist"):
        build(workspace)


def test_manifest_missing_a_required_field_is_rejected(workspace: Path):
    path = workspace / "foundry/agent/agent.manifest.json"
    manifest = json.loads(path.read_text("utf-8"))
    del manifest["prompt_version"]
    path.write_text(json.dumps(manifest), encoding="utf-8")
    with pytest.raises(DefinitionError, match="prompt_version"):
        build(workspace)


def test_unknown_environment_is_rejected():
    with pytest.raises(DefinitionError, match="no parameter_values"):
        environment_binding(ROOT, "no-such-environment")


def test_environment_binding_is_not_in_the_fingerprint():
    """Model deployment differs per environment, so it must not move the hash."""
    definition = build(ROOT)
    assert "model_deployment" not in json.dumps(definition.canonical)
    assert "project_endpoint" not in json.dumps(definition.canonical)
    assert "gpt" not in json.dumps(definition.canonical).lower()


# --- the smoke test's structural checks -----------------------------------

SCHEMA = {
    "type": "object",
    "additionalProperties": False,
    "required": ["category", "confidence", "flag"],
    "properties": {
        "category": {"type": "string", "enum": ["a", "b"]},
        "confidence": {"type": "number", "minimum": 0, "maximum": 1},
        "flag": {"type": "boolean"},
    },
}


def test_a_valid_answer_passes():
    assert validate('{"category":"a","confidence":0.5,"flag":true}', SCHEMA)["category"] == "a"


def test_non_json_is_rejected():
    with pytest.raises(SmokeFailure, match="not valid JSON"):
        validate("I think this is category a.", SCHEMA)


def test_a_missing_required_field_is_rejected():
    with pytest.raises(SmokeFailure, match="missing required fields"):
        validate('{"category":"a","confidence":0.5}', SCHEMA)


def test_an_unexpected_field_is_rejected():
    with pytest.raises(SmokeFailure, match="outside the schema"):
        validate('{"category":"a","confidence":0.5,"flag":true,"extra":1}', SCHEMA)


def test_a_value_outside_the_enum_is_rejected():
    with pytest.raises(SmokeFailure, match="permitted values"):
        validate('{"category":"z","confidence":0.5,"flag":true}', SCHEMA)


def test_a_number_out_of_range_is_rejected():
    with pytest.raises(SmokeFailure, match="above the maximum"):
        validate('{"category":"a","confidence":1.5,"flag":true}', SCHEMA)


def test_a_boolean_of_the_wrong_type_is_rejected():
    with pytest.raises(SmokeFailure, match="not a boolean"):
        validate('{"category":"a","confidence":0.5,"flag":"yes"}', SCHEMA)


def test_an_enum_behind_a_ref_is_still_enforced():
    """Pydantic emits a reused Literal as a $ref; the check must follow it."""
    schema = {
        "type": "object",
        "additionalProperties": False,
        "required": ["category"],
        "properties": {"category": {"$ref": "#/$defs/Cat"}},
        "$defs": {"Cat": {"enum": ["a", "b"]}},
    }
    assert validate('{"category":"a"}', schema)
    with pytest.raises(SmokeFailure, match="permitted values"):
        validate('{"category":"z"}', schema)


# --- the guardrail pre-flight on the prompt itself -------------------------


def test_the_real_instruction_text_is_clean():
    """The prompt we would actually publish must survive the content filter."""
    assert scan(build(ROOT).instructions) == []


def test_bracketed_placeholders_are_not_flagged():
    """The redaction's own output must not trip the check."""
    assert scan("Replace the value with [ACCOUNT] or [NAME] as appropriate.") == []


def test_an_email_address_is_flagged():
    findings = scan("Contact someone.real@example.com for help.")
    assert [f.rule for f in findings] == ["email address"]


def test_a_national_identifier_shape_is_flagged():
    assert any(f.rule == "national identifier" for f in scan("Reference 123-45-6789 applies."))


def test_a_long_digit_run_is_flagged():
    assert any(f.rule == "long digit run" for f in scan("Account 1234567890 is closed."))


def test_a_record_identifier_is_flagged():
    text = "Subject 2DF8DDCD-2A6F-F111-AB0D-70A8A59A6B96 is the key."
    assert any(f.rule == "record identifier" for f in scan(text))


def test_a_finding_never_echoes_the_whole_value():
    """The check must not reproduce the thing that should not be reproduced."""
    secret = "987654321098"
    for finding in scan(f"The number is {secret}."):
        assert secret not in finding.render()


def test_assert_clean_raises_with_actionable_detail():
    with pytest.raises(GuardrailRisk, match="personal-information"):
        assert_clean("Write to first.last@example.org", "the test text")
